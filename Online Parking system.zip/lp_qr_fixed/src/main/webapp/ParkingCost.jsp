<%@page import="com.qrparking.util.DBConnection"%>
<%@page import="java.sql.*"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    HttpSession sess = request.getSession(false);
    if (sess == null || !"admin".equals(sess.getAttribute("role"))) {
        response.sendRedirect("Administrator.jsp?Failed"); return;
    }
%>
<!DOCTYPE html>
<html lang="en">
<head><%@include file="WEB-INF/header.jspf"%></head>
<body>
<% if (request.getParameter("Cost_updated") != null) { %>
<script>window.onload = function(){ alert('Parking cost updated successfully!'); }</script>
<% } %>
<% if (request.getParameter("Failed") != null) { %>
<script>window.onload = function(){ alert('Failed to update. Please try again.'); }</script>
<% } %>

<nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
    <a href="AdminHome.jsp" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <img src="img/logo.png" alt="QR Smart Parking" height="42">
    </a>
    <button class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="AdminHome.jsp" class="nav-item nav-link">Dashboard</a>
            <a href="UserDetails.jsp" class="nav-item nav-link">Users</a>
            <a href="VehicleDetails.jsp" class="nav-item nav-link">Vehicles</a>
            <a href="ParkingCost.jsp" class="nav-item nav-link active">Parking Cost</a>
            <a href="Bookings.jsp" class="nav-item nav-link">Bookings</a>
            <a href="ParkingLogs.jsp" class="nav-item nav-link">Parking Logs</a>
            <a href="logout" class="nav-item nav-link text-danger">Logout</a>
        </div>
    </div>
</nav>
<div class="page-header"><div class="container py-3">
    <h2><i class="fa fa-rupee-sign me-2"></i>Parking Cost Management</h2>
</div></div>
<div class="container py-4">
    <div class="row g-4">
        <%
        try (Connection con = DBConnection.getConnection();
             ResultSet rs = con.createStatement().executeQuery("SELECT * FROM parking_cost")) {
            while (rs.next()) {
                String vtype = rs.getString("vehicle_type");
                int cost = rs.getInt("cost_per_hour");
                String icon = "Car".equals(vtype) ? "🚗" : "Bike".equals(vtype) ? "🏍" :
                              "SUV".equals(vtype) ? "🚙" : "🚛";
        %>
        <div class="col-md-3">
            <div class="form-card text-center">
                <div style="font-size:2.5rem;margin-bottom:8px"><%= icon %></div>
                <h5><%= vtype %></h5>
                <p class="text-success fw-bold fs-4">&#8377;<%= cost %>/hr</p>
                <form action="UpdateCost" method="post">
                    <input type="hidden" name="vehicle_type" value="<%= vtype %>">
                    <div class="input-group">
                        <span class="input-group-text">&#8377;</span>
                        <input type="number" class="form-control" name="cost_per_hour"
                               value="<%= cost %>" min="1" max="1000" required>
                        <span class="input-group-text">/hr</span>
                    </div>
                    <button type="submit" class="btn btn-danger w-100 mt-2">Update</button>
                </form>
            </div>
        </div>
        <% } } catch(Exception e){ e.printStackTrace(); } %>
    </div>
</div>
<div class="footer pt-4 pb-3 mt-5"><div class="container text-center">
    <p class="mb-0">&copy; 2024 QR Smart Vehicle Parking. All rights reserved.</p>
</div></div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
