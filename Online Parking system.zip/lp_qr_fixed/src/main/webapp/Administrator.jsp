<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <%@include file="WEB-INF/header.jspf"%>
</head>
<body>

<%-- Show alerts based on URL params --%>
<% if (request.getParameter("Failed") != null) { %>
<script>window.onload = function(){ alert('Incorrect username or password. Please try again.'); }</script>
<% } %>

<nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
    <a href="index.jsp" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <img src="img/logo.png" alt="QR Smart Parking" height="42">
    </a>
    <div class="collapse navbar-collapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="index.jsp" class="nav-item nav-link">Home</a>
            <a href="Administrator.jsp" class="nav-item nav-link active">Administrator</a>
            <a href="Users.jsp" class="nav-item nav-link">User Login</a>
            <a href="Register.jsp" class="nav-item nav-link">Register</a>
        </div>
    </div>
</nav>

<div class="page-header">
    <div class="container text-center py-4">
        <h1><i class="fa fa-user-shield me-2"></i>Administrator Login</h1>
    </div>
</div>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="form-card">
                <h4 class="text-center mb-4"><i class="fa fa-lock me-2 text-danger"></i>Admin Portal</h4>
                <form action="Adminlog" method="post">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Username</label>
                        <input type="text" class="form-control form-control-lg" name="name"
                               placeholder="Enter admin username" required>
                    </div>
                    <div class="mb-4">
                        <label class="form-label fw-semibold">Password</label>
                        <input type="password" class="form-control form-control-lg" name="pass"
                               placeholder="Enter password" required>
                    </div>
                    <button type="submit" class="btn btn-danger w-100 btn-lg">
                        <i class="fa fa-sign-in-alt me-2"></i>Login as Admin
                    </button>
                </form>
                <hr class="my-3">
                <p class="text-center text-muted small">
                    Default: <strong>admin / admin123</strong>
                </p>
            </div>
        </div>
    </div>
</div>

<div class="footer pt-4 pb-3 mt-5">
    <div class="container text-center">
        <p class="mb-0">&copy; 2024 QR Smart Vehicle Parking. All rights reserved.</p>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
