<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head><%@include file="WEB-INF/header.jspf"%></head>
<body>
<% if (request.getParameter("Error") != null) {
    String err = request.getParameter("Error");
    String msg = "email_exists".equals(err)    ? "Email already registered. Please use a different email." :
                 "missing_fields".equals(err)  ? "Please fill all required fields (Name, Email, Password)." :
                 "register_failed".equals(err) ? "Registration failed. Please try again." :
                 "db_error".equals(err)        ? "Database error. Please ensure MySQL is running and the database is set up correctly." :
                 "Registration failed. Please try again.";
%>
<script>window.onload = function(){ alert('<%= msg %>'); }</script>
<% } %>

<nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
    <a href="index.jsp" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <img src="img/logo.png" alt="QR Smart Parking" height="42">
    </a>
    <button class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="index.jsp" class="nav-item nav-link">Home</a>
            <a href="Users.jsp" class="nav-item nav-link">Login</a>
            <a href="Register.jsp" class="nav-item nav-link active">Register</a>
        </div>
    </div>
</nav>

<div class="page-header">
    <div class="container text-center py-4">
        <h1><i class="fa fa-user-plus me-2"></i>Create Account</h1>
    </div>
</div>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="form-card">
                <h4 class="mb-4"><i class="fa fa-id-card me-2 text-danger"></i>User Registration</h4>
                <form action="UserRegister" method="post" id="regForm">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Full Name *</label>
                            <input type="text" class="form-control" name="name" placeholder="Enter full name" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Email Address *</label>
                            <input type="email" class="form-control" name="email" placeholder="Enter email" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Date of Birth</label>
                            <input type="date" class="form-control" name="dob">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Gender</label>
                            <select class="form-control" name="gender">
                                <option value="">Select</option>
                                <option>Male</option>
                                <option>Female</option>
                                <option>Other</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Phone Number</label>
                            <input type="tel" class="form-control" name="phone" placeholder="e.g. 9876543210"
                                   pattern="[0-9]{10}" title="10-digit phone number">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Password *</label>
                            <input type="password" class="form-control" name="password" id="pass"
                                   placeholder="Min 6 characters" minlength="6" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold">Address</label>
                            <textarea class="form-control" name="address" rows="2" placeholder="Enter address"></textarea>
                        </div>
                    </div>
                    <hr class="my-4">
                    <h5 class="mb-3"><i class="fa fa-car me-2 text-success"></i>Add Vehicle (Optional)</h5>
                    <p class="text-muted small">You can also add vehicles later from your profile.</p>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Vehicle Number</label>
                            <input type="text" class="form-control" name="vehicle_number"
                                   placeholder="e.g. MH12AB1234" style="text-transform:uppercase">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Vehicle Type</label>
                            <select class="form-control" name="vehicle_type">
                                <option>Car</option>
                                <option>Bike</option>
                                <option>SUV</option>
                                <option>Truck</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Brand</label>
                            <input type="text" class="form-control" name="vehicle_brand" placeholder="e.g. Maruti">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Model</label>
                            <input type="text" class="form-control" name="vehicle_model" placeholder="e.g. Swift">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Color</label>
                            <input type="text" class="form-control" name="vehicle_color" placeholder="e.g. White">
                        </div>
                    </div>
                    <div class="mt-4">
                        <button type="submit" class="btn btn-danger btn-lg w-100">
                            <i class="fa fa-user-plus me-2"></i>Register Now
                        </button>
                    </div>
                </form>
                <hr class="my-3">
                <p class="text-center text-muted">Already have an account?
                    <a href="Users.jsp" class="text-danger fw-semibold">Login Here</a>
                </p>
            </div>
        </div>
    </div>
</div>

<div class="footer pt-4 pb-3 mt-5"><div class="container text-center">
    <p class="mb-0">&copy; 2024 QR Smart Vehicle Parking. All rights reserved.</p>
</div></div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
