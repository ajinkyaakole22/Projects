<%@page import="com.qrparking.util.DBConnection"%>
<%@page import="java.sql.*"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    HttpSession sess = request.getSession(false);
    if (sess == null || !"admin".equals(sess.getAttribute("role"))) {
        response.sendRedirect("Administrator.jsp?Failed"); return;
    }
%>
<!DOCTYPE html>
<html lang="en">
<head><%@include file="WEB-INF/header.jspf"%></head>
<body>
<nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
    <a href="AdminHome.jsp" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <img src="img/logo.png" alt="QR Smart Parking" height="42">
    </a>
    <button class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="AdminHome.jsp" class="nav-item nav-link">Dashboard</a>
            <a href="UserDetails.jsp" class="nav-item nav-link">Users</a>
            <a href="VehicleDetails.jsp" class="nav-item nav-link">Vehicles</a>
            <a href="ParkingCost.jsp" class="nav-item nav-link">Parking Cost</a>
            <a href="Bookings.jsp" class="nav-item nav-link active">Bookings</a>
            <a href="ParkingLogs.jsp" class="nav-item nav-link">Parking Logs</a>
            <a href="logout" class="nav-item nav-link text-danger">Logout</a>
        </div>
    </div>
</nav>
<div class="page-header"><div class="container py-3">
    <h2><i class="fa fa-clipboard-list me-2"></i>All Bookings</h2>
</div></div>
<div class="container py-4">
    <div class="form-card">
        <div class="row mb-3">
            <div class="col-md-4">
                <input type="text" id="searchInput" class="form-control" placeholder="Search by user, vehicle, slot...">
            </div>
            <div class="col-md-3">
                <select id="statusFilter" class="form-control">
                    <option value="">All Statuses</option>
                    <option>Pending</option><option>Used</option><option>Cancelled</option>
                </select>
            </div>
        </div>
        <div class="table-responsive">
            <table class="data-table" id="bookingsTable">
                <tr>
                    <th>#</th><th>User</th><th>Vehicle No.</th><th>Type</th>
                    <th>Date</th><th>Start</th><th>End</th><th>Slot</th>
                    <th>Cost</th><th>Payment</th><th>Booked At</th><th>Status</th>
                </tr>
                <%
                try (Connection con = DBConnection.getConnection();
                     ResultSet rs = con.createStatement().executeQuery(
                         "SELECT * FROM slot_booking ORDER BY id DESC")) {
                    int i = 1;
                    while (rs.next()) {
                        String st = rs.getString("ustatus");
                        String badge = "Used".equals(st) ? "bg-success" : "Pending".equals(st) ? "bg-warning text-dark" : "bg-secondary";
                        String stimeF = rs.getString("stime"), etimeF = rs.getString("endtime");
                        try {
                            SimpleDateFormat f24 = new SimpleDateFormat("HH:mm:ss");
                            SimpleDateFormat f12 = new SimpleDateFormat("hh:mm a");
                            stimeF = f12.format(f24.parse(stimeF));
                            etimeF = f12.format(f24.parse(etimeF));
                        } catch(Exception e){}
                %>
                <tr>
                    <td><%= i++ %></td>
                    <td><%= rs.getString("uname") %></td>
                    <td><strong><%= rs.getString("vehicle_number") %></strong></td>
                    <td><%= rs.getString("vehicle_type") %></td>
                    <td><%= rs.getString("pdate") %></td>
                    <td><%= stimeF %></td>
                    <td><%= etimeF %></td>
                    <td><%= rs.getString("slot_name") %></td>
                    <td>&#8377;<%= rs.getString("pcost") %></td>
                    <td><%= rs.getString("payment_mode") %></td>
                    <td><%= rs.getString("booked_at") %></td>
                    <td><span class="badge <%= badge %>"><%= st %></span></td>
                </tr>
                <% } } catch(Exception e){ e.printStackTrace(); } %>
            </table>
        </div>
    </div>
</div>
<div class="footer pt-4 pb-3 mt-5"><div class="container text-center">
    <p class="mb-0">&copy; 2024 QR Smart Vehicle Parking. All rights reserved.</p>
</div></div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.getElementById('searchInput').addEventListener('keyup', filterTable);
    document.getElementById('statusFilter').addEventListener('change', filterTable);
    function filterTable() {
        var s = document.getElementById('searchInput').value.toLowerCase();
        var st = document.getElementById('statusFilter').value.toLowerCase();
        document.querySelectorAll('#bookingsTable tr:not(:first-child)').forEach(function(r) {
            var t = r.innerText.toLowerCase();
            r.style.display = (t.includes(s) && (!st || t.includes(st))) ? '' : 'none';
        });
    }
</script>
</body>
</html>
