<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head><%@include file="WEB-INF/header.jspf"%></head>
<body>
<% if (request.getParameter("Invalid") != null) { %>
<script>window.onload = function(){ alert('Invalid QR code or ticket not found.'); }</script>
<% } %>
<% if (request.getParameter("AlreadyUsed") != null) { %>
<script>window.onload = function(){ alert('This ticket has already been used!'); }</script>
<% } %>

<nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
    <a href="index.jsp" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <img src="img/logo.png" alt="QR Smart Parking" height="42">
    </a>
    <div class="collapse navbar-collapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="AdminHome.jsp" class="nav-item nav-link">Dashboard</a>
            <a href="CheckParking.jsp" class="nav-item nav-link active">Check Ticket</a>
            <a href="ParkingLogs.jsp" class="nav-item nav-link">Parking Logs</a>
            <a href="logout" class="nav-item nav-link text-danger">Logout</a>
        </div>
    </div>
</nav>

<div class="page-header"><div class="container py-3">
    <h2><i class="fa fa-qrcode me-2"></i>QR Ticket Scanner</h2>
    <p class="mb-0">Scan vehicle QR tickets at the parking gate</p>
</div></div>

<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="form-card text-center">
                <h5 class="mb-3"><i class="fa fa-camera me-2 text-danger"></i>Camera QR Scanner</h5>
                <div id="cameraSection">
                    <video id="qrPreview" style="width:100%;max-width:400px;border-radius:8px;border:2px solid #dee2e6"></video>
                    <div id="scanStatus" class="mt-3 text-muted">
                        <i class="fa fa-circle-notch fa-spin me-2"></i>Initializing camera...
                    </div>
                </div>
                <hr class="my-4">
                <h5 class="mb-3"><i class="fa fa-keyboard me-2 text-danger"></i>Manual Entry</h5>
                <p class="text-muted small">Enter the QR code value manually if camera is unavailable</p>
                <form action="verifyTicket" method="get" class="d-flex gap-2">
                    <input type="text" name="qr" class="form-control form-control-lg"
                           placeholder="Enter QR code value" required style="text-transform:uppercase"
                           oninput="this.value = this.value.toUpperCase()">
                    <button type="submit" class="btn btn-danger btn-lg">Verify</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="footer pt-4 pb-3 mt-5"><div class="container text-center">
    <p class="mb-0">&copy; 2024 QR Smart Vehicle Parking. All rights reserved.</p>
</div></div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>
<script>
    try {
        const html5QrCode = new Html5Qrcode("qrPreview");
        const config = { fps: 10, qrbox: { width: 250, height: 250 } };
        html5QrCode.start(
            { facingMode: "environment" },
            config,
            function(decodedText) {
                document.getElementById('scanStatus').innerHTML =
                    '<i class="fa fa-check-circle text-success me-2"></i>QR Scanned! Verifying...';
                html5QrCode.stop();
                setTimeout(function() {
                    window.location.href = 'verifyTicket?qr=' + encodeURIComponent(decodedText);
                }, 1000);
            },
            function(error) {}
        ).then(function() {
            document.getElementById('scanStatus').innerHTML =
                '<i class="fa fa-circle text-success me-2"></i>Camera active. Point at QR code.';
        }).catch(function(err) {
            document.getElementById('scanStatus').innerHTML =
                '<i class="fa fa-exclamation-triangle text-warning me-2"></i>Camera not available. Use manual entry below.';
        });
    } catch(e) {
        document.getElementById('scanStatus').innerHTML =
            '<i class="fa fa-exclamation-triangle text-warning me-2"></i>Scanner not supported. Use manual entry below.';
    }
</script>
</body>
</html>
