<%@page import="com.qrparking.util.DBConnection"%>
<%@page import="java.sql.*"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    HttpSession sess = request.getSession(false);
    if (sess == null || !"user".equals(sess.getAttribute("role"))) {
        response.sendRedirect("Users.jsp?Failed"); return;
    }
    int userId = (int) sess.getAttribute("userId");
%>
<!DOCTYPE html>
<html lang="en">
<head><%@include file="WEB-INF/header.jspf"%></head>
<body>
<nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
    <a href="UserHome.jsp" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <img src="img/logo.png" alt="QR Smart Parking" height="42">
    </a>
    <button class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="UserHome.jsp" class="nav-item nav-link">Home</a>
            <a href="MyVehicles.jsp" class="nav-item nav-link">My Vehicles</a>
            <a href="Book_parking.jsp" class="nav-item nav-link">Book Slot</a>
            <a href="your_bookings.jsp" class="nav-item nav-link active">My Bookings</a>
            <a href="logout" class="nav-item nav-link text-danger">Logout</a>
        </div>
    </div>
</nav>

<div class="page-header"><div class="container py-3">
    <h2><i class="fa fa-clipboard-list me-2"></i>My Bookings</h2>
</div></div>

<div class="container py-4">
    <div class="form-card">
        <div class="table-responsive">
            <table class="data-table">
                <tr>
                    <th>#</th><th>Date</th><th>Vehicle No.</th><th>Type</th>
                    <th>Start</th><th>End</th><th>Slot</th><th>Cost</th>
                    <th>Payment</th><th>Status</th><th>Ticket</th>
                </tr>
                <%
                try (Connection con = DBConnection.getConnection();
                     PreparedStatement ps = con.prepareStatement(
                         "SELECT * FROM slot_booking WHERE uid=? ORDER BY id DESC")) {
                    ps.setString(1, String.valueOf(userId));
                    ResultSet rs = ps.executeQuery();
                    int i = 1;
                    boolean any = false;
                    while (rs.next()) {
                        any = true;
                        String st = rs.getString("ustatus");
                        String badgeClass = "Used".equals(st) ? "bg-success" : "Pending".equals(st) ? "bg-warning text-dark" : "bg-secondary";
                        String stimeF = rs.getString("stime"), etimeF = rs.getString("endtime");
                        try {
                            SimpleDateFormat f24 = new SimpleDateFormat("HH:mm:ss");
                            SimpleDateFormat f12 = new SimpleDateFormat("hh:mm a");
                            stimeF = f12.format(f24.parse(stimeF));
                            etimeF = f12.format(f24.parse(etimeF));
                        } catch(Exception e) {}
                %>
                <tr>
                    <td><%= i++ %></td>
                    <td><%= rs.getString("pdate") %></td>
                    <td><strong><%= rs.getString("vehicle_number") %></strong></td>
                    <td><%= rs.getString("vehicle_type") %></td>
                    <td><%= stimeF %></td>
                    <td><%= etimeF %></td>
                    <td><%= rs.getString("slot_name") %></td>
                    <td>&#8377;<%= rs.getString("pcost") %></td>
                    <td><%= rs.getString("payment_mode") %></td>
                    <td><span class="badge <%= badgeClass %>"><%= st %></span></td>
                    <td>
                        <a href="DownloadTicket.jsp?reqid=<%= rs.getInt("id") %>"
                           class="btn btn-sm btn-outline-danger">
                            <i class="fa fa-ticket-alt"></i>
                        </a>
                    </td>
                </tr>
                <%  }
                    if (!any) { %>
                <tr><td colspan="11" class="text-center py-4 text-muted">
                    No bookings yet. <a href="Book_parking.jsp">Book a slot now!</a>
                </td></tr>
                <% } } catch(Exception e){ e.printStackTrace(); } %>
            </table>
        </div>
    </div>
</div>

<div class="footer pt-4 pb-3 mt-5"><div class="container text-center">
    <p class="mb-0">&copy; 2024 QR Smart Vehicle Parking. All rights reserved.</p>
</div></div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
