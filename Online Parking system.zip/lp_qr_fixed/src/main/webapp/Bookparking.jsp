<%@page import="com.qrparking.util.DBConnection"%>
<%@page import="java.sql.*"%>
<%@page import="java.util.Set"%>
<%@page import="java.util.HashSet"%>
<%@page import="java.util.TimeZone"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    HttpSession sess = request.getSession(false);
    if (sess == null || !"user".equals(sess.getAttribute("role"))) {
        response.sendRedirect("Users.jsp?Failed"); return;
    }
    int userId = (int) sess.getAttribute("userId");

    String pdate = request.getParameter("date");
    String stime = request.getParameter("stime");
    String phrs  = request.getParameter("phrs");
    String vehId = request.getParameter("vehicle_id");

    if (pdate == null || stime == null || phrs == null) {
        response.sendRedirect("Book_parking.jsp"); return;
    }

    String stime1 = stime + ":00";
    String etime  = "";
    int    pcost  = 40;
    int    totalCost = 0;
    String vehicleNumber = "";
    String vehicleType   = "Car";
    Set<String> bookedSlots = new HashSet<>();

    try {
        // FIX: Use fully-qualified java.util.Date to avoid ambiguity with java.sql.Date
        SimpleDateFormat tf = new SimpleDateFormat("HH:mm:ss");
        tf.setTimeZone(TimeZone.getTimeZone("UTC"));
        java.util.Date d1 = tf.parse(stime + ":00");
        java.util.Date d2 = tf.parse(phrs  + ":00:00");
        etime = tf.format(new java.util.Date(d1.getTime() + d2.getTime()));

        try (Connection con = DBConnection.getConnection()) {
            // Get vehicle info
            if (vehId != null && !vehId.isEmpty()) {
                PreparedStatement vps = con.prepareStatement(
                    "SELECT * FROM vehicle_details WHERE id=? AND user_id=?");
                vps.setString(1, vehId);
                vps.setInt(2, userId);
                ResultSet vrs = vps.executeQuery();
                if (vrs.next()) {
                    vehicleNumber = vrs.getString("vehicle_number");
                    vehicleType   = vrs.getString("vehicle_type");
                }
            }

            // Get parking cost for vehicle type
            PreparedStatement cps = con.prepareStatement(
                "SELECT cost_per_hour FROM parking_cost WHERE vehicle_type=?");
            cps.setString(1, vehicleType);
            ResultSet crs = cps.executeQuery();
            if (crs.next()) pcost = crs.getInt("cost_per_hour");
            else pcost = 40;
            totalCost = pcost * Integer.parseInt(phrs);

            // Get booked slots with proper overlap check
            PreparedStatement bps = con.prepareStatement(
                "SELECT slot_name FROM slot_booking WHERE pdate=? AND NOT (endtime <= ? OR stime >= ?)");
            bps.setString(1, pdate);
            bps.setString(2, stime1);
            bps.setString(3, etime);
            ResultSet brs = bps.executeQuery();
            while (brs.next()) bookedSlots.add(brs.getString("slot_name"));
        }
    } catch (Exception ex) { ex.printStackTrace(); }
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <%@include file="WEB-INF/header.jspf"%>
    <style>
        .slot-btn {
            width: 68px; height: 55px; border-radius: 8px; border: 2px solid #28a745;
            background: #f0fff4; font-size: 0.72rem; font-weight: 600; cursor: pointer;
            display: flex; flex-direction: column; align-items: center; justify-content: center;
            transition: all .15s; position: relative;
        }
        .slot-btn:hover { background: #d4edda; }
        .slot-btn.booked {
            border-color: #dc3545; background: #fff0f0; color: #dc3545; cursor: not-allowed;
        }
        .slot-btn.selected {
            border-color: #0B2154; background: #0B2154; color: #fff;
        }
        .slot-row-label { font-weight: 700; color: #0B2154; width: 30px; text-align: center; }
        .road-lane { height: 30px; background: repeating-linear-gradient(90deg,#aaa 0,#aaa 20px,transparent 20px,transparent 40px); opacity: 0.3; margin: 8px 0; border-radius: 4px; }
        .legend-dot { width: 16px; height: 16px; border-radius: 3px; display: inline-block; margin-right: 6px; }
    </style>
</head>
<body>
<% if (request.getParameter("Already") != null) { %>
<script>window.onload = function(){ alert('Slot already booked for selected time. Please choose another slot.'); }</script>
<% } %>

<nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
    <a href="UserHome.jsp" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <img src="img/logo.png" alt="QR Smart Parking" height="42">
    </a>
    <div class="collapse navbar-collapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="UserHome.jsp" class="nav-item nav-link">Home</a>
            <a href="MyVehicles.jsp" class="nav-item nav-link">My Vehicles</a>
            <a href="Book_parking.jsp" class="nav-item nav-link active">Book Slot</a>
            <a href="your_bookings.jsp" class="nav-item nav-link">My Bookings</a>
            <a href="logout" class="nav-item nav-link text-danger">Logout</a>
        </div>
    </div>
</nav>

<div class="page-header"><div class="container py-3">
    <h2><i class="fa fa-map-marked-alt me-2"></i>Select Parking Slot</h2>
    <p class="mb-0">Step 2: Choose your preferred slot</p>
</div></div>

<div class="container py-4">
    <!-- Step indicator -->
    <div class="d-flex align-items-center mb-4">
        <div class="rounded-circle bg-success text-white d-flex align-items-center justify-content-center" style="width:36px;height:36px;font-weight:700">✓</div>
        <div style="height:2px;width:60px;background:#28a745;margin:0 8px"></div>
        <div class="rounded-circle bg-danger text-white d-flex align-items-center justify-content-center" style="width:36px;height:36px;font-weight:700">2</div>
        <div style="height:2px;width:60px;background:#dee2e6;margin:0 8px"></div>
        <div class="rounded-circle bg-light border d-flex align-items-center justify-content-center" style="width:36px;height:36px;color:#999;font-weight:700">3</div>
    </div>

    <div class="row g-4">
        <!-- Booking Summary -->
        <div class="col-md-3">
            <div class="form-card">
                <h6 class="fw-bold text-danger mb-3"><i class="fa fa-info-circle me-2"></i>Booking Summary</h6>
                <p class="mb-1"><strong>Date:</strong> <%= pdate %></p>
                <p class="mb-1"><strong>Start:</strong> <%= stime %></p>
                <p class="mb-1"><strong>End:</strong> <%= etime %></p>
                <p class="mb-1"><strong>Duration:</strong> <%= phrs %> hr(s)</p>
                <p class="mb-1"><strong>Vehicle:</strong> <%= vehicleNumber %></p>
                <p class="mb-1"><strong>Type:</strong> <%= vehicleType %></p>
                <hr>
                <p class="mb-0"><strong>Total Cost:</strong><br>
                    <span class="text-success fs-5 fw-bold">&#8377;<%= totalCost %></span>
                </p>
            </div>
            <!-- Legend -->
            <div class="form-card mt-3">
                <h6 class="fw-bold mb-2">Legend</h6>
                <div class="mb-1"><span class="legend-dot" style="background:#f0fff4;border:2px solid #28a745"></span> Available</div>
                <div class="mb-1"><span class="legend-dot" style="background:#fff0f0;border:2px solid #dc3545"></span> Booked</div>
                <div><span class="legend-dot" style="background:#0B2154;border:2px solid #0B2154"></span> Your Selection</div>
            </div>
        </div>

        <!-- Slot Map -->
        <div class="col-md-9">
            <div class="form-card">
                <h5 class="fw-bold mb-1"><i class="fa fa-th me-2 text-danger"></i>Parking Lot Map</h5>
                <p class="text-muted small mb-3">Click on a green slot to select it. Red slots are already booked.</p>

                <form action="slot_booking" method="post" id="bookingForm">
                    <input type="hidden" name="pdate"          value="<%= pdate %>">
                    <input type="hidden" name="stime"          value="<%= stime %>">
                    <input type="hidden" name="phrs"           value="<%= phrs %>">
                    <input type="hidden" name="totalcost"      value="<%= totalCost %>">
                    <input type="hidden" name="vehicle_number" value="<%= vehicleNumber %>">
                    <input type="hidden" name="vehicle_type"   value="<%= vehicleType %>">
                    <input type="hidden" name="certype"        value="Cash" id="paymentMode">
                    <input type="hidden" name="Slot"           id="selectedSlot" value="">

                    <!-- Slot Grid: Row A (1-10), B (11-20), C (21-30) -->
                    <% String[] rows = {"A","B","C"}; %>
                    <% for (int row = 0; row < 3; row++) { %>
                        <div class="d-flex align-items-center gap-2 mb-2 flex-wrap">
                            <span class="slot-row-label"><%= rows[row] %></span>
                            <% for (int col = 1; col <= 10; col++) {
                                int slotNum = row * 10 + col;
                                String slotName = "Slot " + slotNum;
                                boolean isBooked = bookedSlots.contains(slotName);
                            %>
                            <button type="button"
                                    class="slot-btn <%= isBooked ? "booked" : "" %>"
                                    data-slot="<%= slotName %>"
                                    <%= isBooked ? "disabled title='Already booked'" : "" %>
                                    onclick="selectSlot(this)">
                                <span><%= rows[row] %><%= col %></span>
                                <% if (!isBooked) { %><i class="fa fa-car" style="font-size:0.65rem;opacity:0.6"></i><% } %>
                            </button>
                            <% if (col == 5) { %>
                            <div style="width:20px"></div>
                            <% } %>
                            <% } %>
                        </div>
                        <% if (row < 2) { %><div class="road-lane"></div><% } %>
                    <% } %>

                    <div class="mt-4">
                        <div id="selectedDisplay" class="alert alert-info" style="display:none">
                            &#10003; Selected: <strong id="selectedSlotDisplay"></strong>
                        </div>
                    </div>

                    <!-- Payment Mode -->
                    <div class="row mt-3">
                        <div class="col-md-5">
                            <label class="form-label fw-semibold">Payment Mode</label>
                            <select class="form-control" onchange="document.getElementById('paymentMode').value=this.value">
                                <option value="Cash">Cash</option>
                                <option value="UPI">UPI</option>
                                <option value="Credit/Debit Card">Credit/Debit Card</option>
                            </select>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-danger btn-lg mt-4 px-5" id="bookBtn" disabled>
                        <i class="fa fa-check-circle me-2"></i>Confirm Booking
                    </button>
                    <a href="Book_parking.jsp" class="btn btn-outline-secondary btn-lg mt-4 ms-2">Back</a>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="footer pt-4 pb-3 mt-5"><div class="container text-center">
    <p class="mb-0">&copy; 2024 QR Smart Vehicle Parking. All rights reserved.</p>
</div></div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    var selectedBtn = null;
    function selectSlot(btn) {
        if (selectedBtn) selectedBtn.classList.remove('selected');
        btn.classList.add('selected');
        selectedBtn = btn;
        var slot = btn.dataset.slot;
        document.getElementById('selectedSlot').value = slot;
        document.getElementById('selectedSlotDisplay').textContent = slot;
        document.getElementById('selectedDisplay').style.display = 'block';
        document.getElementById('bookBtn').disabled = false;
    }
    document.getElementById('bookingForm').addEventListener('submit', function(e) {
        if (!document.getElementById('selectedSlot').value) {
            e.preventDefault();
            alert('Please select a parking slot first.');
        }
    });
</script>
</body>
</html>
