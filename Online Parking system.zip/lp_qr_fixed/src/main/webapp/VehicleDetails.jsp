<%@page import="com.qrparking.util.DBConnection"%>
<%@page import="java.sql.*"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    HttpSession sess = request.getSession(false);
    if (sess == null || !"admin".equals(sess.getAttribute("role"))) {
        response.sendRedirect("Administrator.jsp?Failed"); return;
    }
%>
<!DOCTYPE html>
<html lang="en">
<head><%@include file="WEB-INF/header.jspf"%></head>
<body>
<nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
    <a href="AdminHome.jsp" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <img src="img/logo.png" alt="QR Smart Parking" height="42">
    </a>
    <button class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="AdminHome.jsp" class="nav-item nav-link">Dashboard</a>
            <a href="UserDetails.jsp" class="nav-item nav-link">Users</a>
            <a href="VehicleDetails.jsp" class="nav-item nav-link active">Vehicles</a>
            <a href="ParkingCost.jsp" class="nav-item nav-link">Parking Cost</a>
            <a href="Bookings.jsp" class="nav-item nav-link">Bookings</a>
            <a href="ParkingLogs.jsp" class="nav-item nav-link">Parking Logs</a>
            <a href="logout" class="nav-item nav-link text-danger">Logout</a>
        </div>
    </div>
</nav>
<div class="page-header"><div class="container py-3">
    <h2><i class="fa fa-car me-2"></i>All Registered Vehicles</h2>
</div></div>
<div class="container py-4">
    <div class="form-card">
        <!-- Search -->
        <div class="row mb-3">
            <div class="col-md-4">
                <input type="text" id="searchInput" class="form-control" placeholder="Search by vehicle number, user...">
            </div>
            <div class="col-md-3">
                <select id="typeFilter" class="form-control">
                    <option value="">All Types</option>
                    <option>Car</option><option>Bike</option><option>SUV</option><option>Truck</option>
                </select>
            </div>
        </div>
        <div class="table-responsive">
            <table class="data-table" id="vehicleTable">
                <tr>
                    <th>#</th><th>Vehicle Number</th><th>Type</th><th>Brand</th>
                    <th>Model</th><th>Color</th><th>Owner</th><th>Registered On</th>
                </tr>
                <%
                try (Connection con = DBConnection.getConnection();
                     ResultSet rs = con.createStatement().executeQuery(
                         "SELECT v.*, u.name AS owner_name FROM vehicle_details v " +
                         "LEFT JOIN user_reg u ON v.user_id = u.id ORDER BY v.id DESC")) {
                    int i = 1;
                    while (rs.next()) {
                        String type = rs.getString("vehicle_type");
                        String icon = "Car".equals(type) ? "🚗" : "Bike".equals(type) ? "🏍" :
                                      "SUV".equals(type) ? "🚙" : "🚛";
                %>
                <tr>
                    <td><%= i++ %></td>
                    <td><strong><%= rs.getString("vehicle_number") %></strong></td>
                    <td><%= icon %> <%= type %></td>
                    <td><%= rs.getString("vehicle_brand") %></td>
                    <td><%= rs.getString("vehicle_model") %></td>
                    <td>
                        <span style="display:inline-block;width:16px;height:16px;border-radius:50%;background:<%= rs.getString("vehicle_color").toLowerCase() %>;border:1px solid #ccc;vertical-align:middle;margin-right:4px"></span>
                        <%= rs.getString("vehicle_color") %>
                    </td>
                    <td><%= rs.getString("owner_name") != null ? rs.getString("owner_name") : "N/A" %></td>
                    <td><%= rs.getString("created_at") %></td>
                </tr>
                <% } } catch(Exception e){ e.printStackTrace(); } %>
            </table>
        </div>
    </div>
</div>
<div class="footer pt-4 pb-3 mt-5"><div class="container text-center">
    <p class="mb-0">&copy; 2024 QR Smart Vehicle Parking. All rights reserved.</p>
</div></div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.getElementById('searchInput').addEventListener('keyup', filterTable);
    document.getElementById('typeFilter').addEventListener('change', filterTable);
    function filterTable() {
        var search = document.getElementById('searchInput').value.toLowerCase();
        var type   = document.getElementById('typeFilter').value.toLowerCase();
        var rows = document.querySelectorAll('#vehicleTable tr:not(:first-child)');
        rows.forEach(function(row) {
            var text = row.innerText.toLowerCase();
            var typeMatch = !type || text.includes(type);
            row.style.display = (text.includes(search) && typeMatch) ? '' : 'none';
        });
    }
</script>
</body>
</html>
