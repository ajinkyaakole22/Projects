<%@page import="com.qrparking.util.DBConnection"%>
<%@page import="java.sql.*"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    HttpSession sess = request.getSession(false);
    if (sess == null || !"user".equals(sess.getAttribute("role"))) {
        response.sendRedirect("Users.jsp?Failed"); return;
    }
%>
<!DOCTYPE html>
<html lang="en">
<head><%@include file="WEB-INF/header.jspf"%></head>
<body>
<nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
    <a href="UserHome.jsp" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <img src="img/logo.png" alt="QR Smart Parking" height="42">
    </a>
    <button class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="UserHome.jsp" class="nav-item nav-link">Home</a>
            <a href="MyVehicles.jsp" class="nav-item nav-link">My Vehicles</a>
            <a href="parking_cost1.jsp" class="nav-item nav-link active">Parking Cost</a>
            <a href="Book_parking.jsp" class="nav-item nav-link">Book Slot</a>
            <a href="your_bookings.jsp" class="nav-item nav-link">My Bookings</a>
            <a href="logout" class="nav-item nav-link text-danger">Logout</a>
        </div>
    </div>
</nav>
<div class="page-header"><div class="container py-3">
    <h2><i class="fa fa-rupee-sign me-2"></i>Parking Rates</h2>
</div></div>
<div class="container py-4">
    <div class="row justify-content-center g-4">
        <%
        try (Connection con = DBConnection.getConnection();
             ResultSet rs = con.createStatement().executeQuery("SELECT * FROM parking_cost")) {
            while (rs.next()) {
                String vtype = rs.getString("vehicle_type");
                int cost = rs.getInt("cost_per_hour");
                String icon = "Car".equals(vtype) ? "🚗" : "Bike".equals(vtype) ? "🏍" :
                              "SUV".equals(vtype) ? "🚙" : "🚛";
        %>
        <div class="col-md-3 col-6 text-center">
            <div class="form-card">
                <div style="font-size:3rem;margin-bottom:12px"><%= icon %></div>
                <h4><%= vtype %></h4>
                <div class="text-danger fs-3 fw-bold">&#8377;<%= cost %></div>
                <div class="text-muted">per hour</div>
                <hr>
                <div class="text-muted small">
                    2 hrs: &#8377;<%= cost*2 %> &nbsp;|&nbsp; 3 hrs: &#8377;<%= cost*3 %>
                </div>
            </div>
        </div>
        <% } } catch(Exception e){ e.printStackTrace(); } %>
    </div>
    <div class="text-center mt-4">
        <a href="Book_parking.jsp" class="btn btn-danger btn-lg">
            <i class="fa fa-calendar-plus me-2"></i>Book Now
        </a>
    </div>
</div>
<div class="footer pt-4 pb-3 mt-5"><div class="container text-center">
    <p class="mb-0">&copy; 2024 QR Smart Vehicle Parking. All rights reserved.</p>
</div></div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
