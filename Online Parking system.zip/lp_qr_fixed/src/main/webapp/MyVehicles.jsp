<%@page import="com.qrparking.util.DBConnection"%>
<%@page import="java.sql.*"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    HttpSession sess = request.getSession(false);
    if (sess == null || !"user".equals(sess.getAttribute("role"))) {
        response.sendRedirect("Users.jsp?Failed"); return;
    }
    int userId = (int) sess.getAttribute("userId");
%>
<!DOCTYPE html>
<html lang="en">
<head><%@include file="WEB-INF/header.jspf"%></head>
<body>
<% if (request.getParameter("Success") != null) { String s = request.getParameter("Success");
   String msg = "added".equals(s) ? "Vehicle added successfully!" : "deleted".equals(s) ? "Vehicle removed." : "Default vehicle updated."; %>
<script>window.onload = function(){ alert('<%= msg %>'); }</script>
<% } %>
<% if (request.getParameter("Error") != null) {
   String e = request.getParameter("Error"); String msg = "vehicle_exists".equals(e) ? "Vehicle already registered." : "An error occurred. Please try again."; %>
<script>window.onload = function(){ alert('<%= msg %>'); }</script>
<% } %>

<nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
    <a href="UserHome.jsp" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <img src="img/logo.png" alt="QR Smart Parking" height="42">
    </a>
    <button class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="UserHome.jsp" class="nav-item nav-link">Home</a>
            <a href="MyVehicles.jsp" class="nav-item nav-link active">My Vehicles</a>
            <a href="parking_cost1.jsp" class="nav-item nav-link">Parking Cost</a>
            <a href="Book_parking.jsp" class="nav-item nav-link">Book Slot</a>
            <a href="your_bookings.jsp" class="nav-item nav-link">My Bookings</a>
            <a href="logout" class="nav-item nav-link text-danger">Logout</a>
        </div>
    </div>
</nav>

<div class="page-header"><div class="container py-3">
    <h2><i class="fa fa-car me-2"></i>My Vehicles</h2>
</div></div>

<div class="container py-4">
    <div class="row g-4">
        <!-- Add Vehicle Form -->
        <div class="col-md-4">
            <div class="form-card">
                <h5 class="fw-bold mb-3"><i class="fa fa-plus-circle me-2 text-success"></i>Add New Vehicle</h5>
                <form action="VehicleManage" method="post">
                    <input type="hidden" name="action" value="add">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Vehicle Number *</label>
                        <input type="text" class="form-control" name="vehicle_number"
                               placeholder="e.g. MH12AB1234" required
                               style="text-transform:uppercase"
                               oninput="this.value = this.value.toUpperCase()">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Vehicle Type *</label>
                        <select class="form-control" name="vehicle_type" required>
                            <option>Car</option>
                            <option>Bike</option>
                            <option>SUV</option>
                            <option>Truck</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Brand</label>
                        <input type="text" class="form-control" name="vehicle_brand" placeholder="e.g. Maruti, Honda">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Model</label>
                        <input type="text" class="form-control" name="vehicle_model" placeholder="e.g. Swift, Activa">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Color</label>
                        <input type="text" class="form-control" name="vehicle_color" placeholder="e.g. White, Black">
                    </div>
                    <button type="submit" class="btn btn-success w-100">
                        <i class="fa fa-plus me-2"></i>Add Vehicle
                    </button>
                </form>
            </div>
        </div>

        <!-- Vehicle List -->
        <div class="col-md-8">
            <div class="row g-3">
                <%
                try (Connection con = DBConnection.getConnection();
                     PreparedStatement ps = con.prepareStatement(
                         "SELECT * FROM vehicle_details WHERE user_id=? ORDER BY is_default DESC, id DESC")) {
                    ps.setInt(1, userId);
                    ResultSet rs = ps.executeQuery();
                    boolean any = false;
                    while (rs.next()) {
                        any = true;
                        int vid = rs.getInt("id");
                        String type = rs.getString("vehicle_type");
                        int isDefault = rs.getInt("is_default");
                        String icon = "Car".equals(type) ? "🚗" : "Bike".equals(type) ? "🏍" :
                                      "SUV".equals(type) ? "🚙" : "🚛";
                %>
                <div class="col-md-6">
                    <div class="vehicle-card <%= isDefault == 1 ? "default-vehicle" : "" %>">
                        <% if (isDefault == 1) { %>
                        <span class="badge bg-success" style="position:absolute;top:10px;right:10px">⭐ Default</span>
                        <% } %>
                        <div class="vehicle-type-icon"><%= icon %></div>
                        <h5 class="mb-1"><%= rs.getString("vehicle_number") %></h5>
                        <p class="text-muted mb-1"><strong>Type:</strong> <%= type %></p>
                        <p class="text-muted mb-1"><strong>Brand:</strong> <%= rs.getString("vehicle_brand") %></p>
                        <p class="text-muted mb-1"><strong>Model:</strong> <%= rs.getString("vehicle_model") %></p>
                        <p class="text-muted mb-3"><strong>Color:</strong> <%= rs.getString("vehicle_color") %></p>
                        <div class="d-flex gap-2">
                            <% if (isDefault == 0) { %>
                            <form action="VehicleManage" method="post" class="d-inline">
                                <input type="hidden" name="action" value="setDefault">
                                <input type="hidden" name="vehicle_id" value="<%= vid %>">
                                <button class="btn btn-sm btn-outline-success">Set Default</button>
                            </form>
                            <% } %>
                            <form action="VehicleManage" method="post" class="d-inline"
                                  onsubmit="return confirm('Remove this vehicle?')">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="vehicle_id" value="<%= vid %>">
                                <button class="btn btn-sm btn-outline-danger">
                                    <i class="fa fa-trash"></i> Remove
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <%  }
                    if (!any) { %>
                <div class="col-12">
                    <div class="text-center py-5 text-muted">
                        <i class="fa fa-car fa-3x mb-3 d-block"></i>
                        <h5>No vehicles added yet</h5>
                        <p>Add your vehicle using the form on the left.</p>
                    </div>
                </div>
                <% } } catch(Exception e){ e.printStackTrace(); } %>
            </div>
        </div>
    </div>
</div>

<div class="footer pt-4 pb-3 mt-5"><div class="container text-center">
    <p class="mb-0">&copy; 2024 QR Smart Vehicle Parking. All rights reserved.</p>
</div></div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
