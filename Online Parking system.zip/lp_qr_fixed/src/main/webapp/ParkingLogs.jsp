<%@page import="com.qrparking.util.DBConnection"%>
<%@page import="java.sql.*"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    HttpSession sess = request.getSession(false);
    if (sess == null || !"admin".equals(sess.getAttribute("role"))) {
        response.sendRedirect("Administrator.jsp?Failed"); return;
    }
%>
<!DOCTYPE html>
<html lang="en">
<head><%@include file="WEB-INF/header.jspf"%></head>
<body>
<nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
    <a href="AdminHome.jsp" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <img src="img/logo.png" alt="QR Smart Parking" height="42">
    </a>
    <button class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="AdminHome.jsp" class="nav-item nav-link">Dashboard</a>
            <a href="UserDetails.jsp" class="nav-item nav-link">Users</a>
            <a href="VehicleDetails.jsp" class="nav-item nav-link">Vehicles</a>
            <a href="ParkingCost.jsp" class="nav-item nav-link">Parking Cost</a>
            <a href="Bookings.jsp" class="nav-item nav-link">Bookings</a>
            <a href="ParkingLogs.jsp" class="nav-item nav-link active">Parking Logs</a>
            <a href="logout" class="nav-item nav-link text-danger">Logout</a>
        </div>
    </div>
</nav>
<div class="page-header"><div class="container py-3">
    <h2><i class="fa fa-history me-2"></i>Parking Logs</h2>
    <p class="mb-0">Real-time vehicle entry/exit records</p>
</div></div>
<div class="container py-4">
    <div class="form-card">
        <div class="table-responsive">
            <table class="data-table">
                <tr>
                    <th>#</th><th>Booking ID</th><th>User</th><th>Vehicle No.</th>
                    <th>Slot</th><th>Entry Time</th><th>Exit Time</th><th>Status</th>
                </tr>
                <%
                try (Connection con = DBConnection.getConnection();
                     ResultSet rs = con.createStatement().executeQuery(
                         "SELECT * FROM parking_logs ORDER BY id DESC")) {
                    int i = 1;
                    boolean any = false;
                    while (rs.next()) {
                        any = true;
                        String st = rs.getString("status");
                        String badge = "Parked".equals(st) ? "bg-success" : "bg-secondary";
                %>
                <tr>
                    <td><%= i++ %></td>
                    <td>#<%= rs.getInt("booking_id") %></td>
                    <td><%= rs.getString("uname") %></td>
                    <td><strong><%= rs.getString("vehicle_number") %></strong></td>
                    <td><%= rs.getString("slot_name") %></td>
                    <td><%= rs.getTimestamp("entry_time") %></td>
                    <td><%= rs.getTimestamp("exit_time") != null ? rs.getTimestamp("exit_time") : "—" %></td>
                    <td><span class="badge <%= badge %>"><%= st %></span></td>
                </tr>
                <%  }
                    if (!any) { %>
                <tr><td colspan="8" class="text-center py-4 text-muted">No parking logs yet.</td></tr>
                <% } } catch(Exception e){ e.printStackTrace(); } %>
            </table>
        </div>
    </div>
</div>
<div class="footer pt-4 pb-3 mt-5"><div class="container text-center">
    <p class="mb-0">&copy; 2024 QR Smart Vehicle Parking. All rights reserved.</p>
</div></div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
