<%@page import="com.qrparking.util.DBConnection"%>
<%@page import="java.sql.*"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    HttpSession sess = request.getSession(false);
    if (sess == null || !"user".equals(sess.getAttribute("role"))) {
        response.sendRedirect("Users.jsp?Failed"); return;
    }
    int userId = (int) sess.getAttribute("userId");
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <%@include file="WEB-INF/header.jspf"%>
</head>
<body>
<% if (request.getParameter("NoVehicle") != null) { %>
<script>window.onload = function(){ alert('Please add a vehicle first before booking.'); }</script>
<% } %>

<nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
    <a href="UserHome.jsp" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <img src="img/logo.png" alt="QR Smart Parking" height="42">
    </a>
    <button class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="UserHome.jsp" class="nav-item nav-link">Home</a>
            <a href="MyVehicles.jsp" class="nav-item nav-link">My Vehicles</a>
            <a href="parking_cost1.jsp" class="nav-item nav-link">Parking Cost</a>
            <a href="Book_parking.jsp" class="nav-item nav-link active">Book Slot</a>
            <a href="your_bookings.jsp" class="nav-item nav-link">My Bookings</a>
            <a href="logout" class="nav-item nav-link text-danger">Logout</a>
        </div>
    </div>
</nav>

<div class="page-header"><div class="container py-3">
    <h2><i class="fa fa-calendar-plus me-2"></i>Book Parking Slot</h2>
    <p class="mb-0">Step 1: Choose date, time and vehicle</p>
</div></div>

<div class="container py-4">
    <!-- Step indicator -->
    <div class="d-flex align-items-center mb-4">
        <div class="rounded-circle bg-danger text-white d-flex align-items-center justify-content-center" style="width:36px;height:36px;font-weight:700">1</div>
        <div style="height:2px;width:60px;background:#dee2e6;margin:0 8px"></div>
        <div class="rounded-circle bg-light border d-flex align-items-center justify-content-center" style="width:36px;height:36px;color:#999;font-weight:700">2</div>
        <div style="height:2px;width:60px;background:#dee2e6;margin:0 8px"></div>
        <div class="rounded-circle bg-light border d-flex align-items-center justify-content-center" style="width:36px;height:36px;color:#999;font-weight:700">3</div>
    </div>

    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="form-card">
                <h5 class="fw-bold mb-3"><i class="fa fa-search me-2 text-danger"></i>Search Available Slots</h5>
                <form action="Bookparking.jsp" method="get" id="bookForm">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Select Date *</label>
                        <input type="date" class="form-control form-control-lg" name="date" id="date" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Start Time *</label>
                        <select name="stime" class="form-control form-control-lg" required>
                            <option value="">-- Select Time --</option>
                            <option>06:00</option><option>07:00</option><option>08:00</option>
                            <option>09:00</option><option>10:00</option><option>11:00</option>
                            <option>12:00</option><option>13:00</option><option>14:00</option>
                            <option>15:00</option><option>16:00</option><option>17:00</option>
                            <option>18:00</option><option>19:00</option><option>20:00</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Duration (Hours) *</label>
                        <select name="phrs" class="form-control form-control-lg" required>
                            <option value="">-- Select Duration --</option>
                            <option value="1">1 Hour</option>
                            <option value="2">2 Hours</option>
                            <option value="3">3 Hours</option>
                            <option value="4">4 Hours</option>
                            <option value="5">5 Hours</option>
                            <option value="6">6 Hours</option>
                        </select>
                    </div>

                    <!-- Vehicle selection -->
                    <div class="mb-4">
                        <label class="form-label fw-semibold">Select Vehicle *</label>
                        <%
                        try (Connection con = DBConnection.getConnection();
                             PreparedStatement ps = con.prepareStatement(
                                 "SELECT * FROM vehicle_details WHERE user_id=? ORDER BY is_default DESC")) {
                            ps.setInt(1, userId);
                            ResultSet rs = ps.executeQuery();
                            boolean hasVehicles = false;
                        %>
                        <select name="vehicle_id" class="form-control form-control-lg" required id="vehicleSelect">
                            <option value="">-- Select Vehicle --</option>
                            <%
                            while (rs.next()) {
                                hasVehicles = true;
                                String icon = "Car".equals(rs.getString("vehicle_type")) ? "🚗" :
                                              "Bike".equals(rs.getString("vehicle_type")) ? "🏍" :
                                              "SUV".equals(rs.getString("vehicle_type")) ? "🚙" : "🚛";
                            %>
                            <option value="<%= rs.getInt("id") %>"
                                    data-number="<%= rs.getString("vehicle_number") %>"
                                    data-type="<%= rs.getString("vehicle_type") %>"
                                    <%= rs.getInt("is_default") == 1 ? "selected" : "" %>>
                                <%= icon %> <%= rs.getString("vehicle_number") %> - <%= rs.getString("vehicle_brand") %> <%= rs.getString("vehicle_model") %>
                            </option>
                            <%
                            }
                            if (!hasVehicles) {
                            %>
                            </select>
                            <div class="alert alert-warning mt-2">
                                <i class="fa fa-exclamation-triangle me-2"></i>
                                No vehicles found. <a href="MyVehicles.jsp" class="alert-link">Add a vehicle first</a>.
                            </div>
                            <%
                            } else {
                            %>
                            </select>
                            <%
                            }
                        } catch(Exception e){ e.printStackTrace(); }
                        %>
                    </div>

                    <button type="submit" class="btn btn-danger btn-lg w-100">
                        <i class="fa fa-search me-2"></i>Check Available Slots
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="footer pt-4 pb-3 mt-5"><div class="container text-center">
    <p class="mb-0">&copy; 2024 QR Smart Vehicle Parking. All rights reserved.</p>
</div></div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Set min date to today
    var today = new Date().toISOString().split('T')[0];
    var maxDate = new Date(); maxDate.setDate(maxDate.getDate()+365);
    document.getElementById('date').setAttribute('min', today);
    document.getElementById('date').setAttribute('max', maxDate.toISOString().split('T')[0]);
</script>
</body>
</html>
