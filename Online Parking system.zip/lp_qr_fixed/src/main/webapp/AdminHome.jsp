<%@page import="com.qrparking.util.DBConnection"%>
<%@page import="java.sql.*"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    // Session check
    HttpSession sess = request.getSession(false);
    if (sess == null || !"admin".equals(sess.getAttribute("role"))) {
        response.sendRedirect("Administrator.jsp?Failed");
        return;
    }
    String adminName = (String) sess.getAttribute("adminName");

    int totalUsers = 0, totalBookings = 0, activeBookings = 0, totalVehicles = 0;
    double totalRevenue = 0;
    try (Connection con = DBConnection.getConnection()) {
        ResultSet r;
        r = con.createStatement().executeQuery("SELECT COUNT(*) FROM user_reg"); r.next(); totalUsers = r.getInt(1);
        r = con.createStatement().executeQuery("SELECT COUNT(*) FROM slot_booking"); r.next(); totalBookings = r.getInt(1);
        r = con.createStatement().executeQuery("SELECT COUNT(*) FROM slot_booking WHERE ustatus='Pending'"); r.next(); activeBookings = r.getInt(1);
        r = con.createStatement().executeQuery("SELECT COUNT(*) FROM vehicle_details"); r.next(); totalVehicles = r.getInt(1);
        r = con.createStatement().executeQuery("SELECT IFNULL(SUM(CAST(pcost AS UNSIGNED)),0) FROM slot_booking"); r.next(); totalRevenue = r.getDouble(1);
    } catch (Exception e) { e.printStackTrace(); }
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <%@include file="WEB-INF/header.jspf"%>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
    <a href="AdminHome.jsp" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <img src="img/logo.png" alt="QR Smart Parking" height="42">
    </a>
    <button class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="AdminHome.jsp" class="nav-item nav-link active">Dashboard</a>
            <a href="UserDetails.jsp" class="nav-item nav-link">Users</a>
            <a href="VehicleDetails.jsp" class="nav-item nav-link">Vehicles</a>
            <a href="ParkingCost.jsp" class="nav-item nav-link">Parking Cost</a>
            <a href="Bookings.jsp" class="nav-item nav-link">Bookings</a>
            <a href="ParkingLogs.jsp" class="nav-item nav-link">Parking Logs</a>
            <a href="logout" class="nav-item nav-link text-danger"><i class="fa fa-sign-out-alt me-1"></i>Logout</a>
        </div>
    </div>
</nav>

<div style="background: linear-gradient(rgba(11,33,84,0.80),rgba(216,19,36,0.75)), url('img/pexels-jose-espinal-1000633.jpg') center/cover no-repeat; padding:36px 0; color:#fff;">
    <div class="container py-3">
        <h2><i class="fa fa-tachometer-alt me-2"></i>Admin Dashboard</h2>
        <p class="mb-0">Welcome back, <strong><%= adminName %></strong></p>
    </div>
</div>

<div class="container py-4">
    <!-- Stats -->
    <div class="row g-4 mb-4">
        <div class="col-md-3 col-6">
            <div class="stat-card bg-danger">
                <div class="stat-number"><%= totalUsers %></div>
                <div class="stat-label"><i class="fa fa-users me-1"></i>Registered Users</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card bg-info">
                <div class="stat-number"><%= totalVehicles %></div>
                <div class="stat-label"><i class="fa fa-car me-1"></i>Registered Vehicles</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card bg-warning">
                <div class="stat-number"><%= totalBookings %></div>
                <div class="stat-label"><i class="fa fa-calendar-check me-1"></i>Total Bookings</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card bg-success">
                <div class="stat-number">&#8377;<%= (int)totalRevenue %></div>
                <div class="stat-label"><i class="fa fa-rupee-sign me-1"></i>Total Revenue</div>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="row g-4 mb-4">
        <div class="col-12">
            <h5 class="fw-bold mb-3">Quick Actions</h5>
        </div>
        <div class="col-md-2 col-4 text-center">
            <a href="UserDetails.jsp" class="text-decoration-none">
                <div class="p-3 border rounded bg-white shadow-sm">
                    <i class="fa fa-users fa-2x text-primary mb-2 d-block"></i>
                    <small>View Users</small>
                </div>
            </a>
        </div>
        <div class="col-md-2 col-4 text-center">
            <a href="VehicleDetails.jsp" class="text-decoration-none">
                <div class="p-3 border rounded bg-white shadow-sm">
                    <i class="fa fa-car fa-2x text-success mb-2 d-block"></i>
                    <small>Vehicles</small>
                </div>
            </a>
        </div>
        <div class="col-md-2 col-4 text-center">
            <a href="Bookings.jsp" class="text-decoration-none">
                <div class="p-3 border rounded bg-white shadow-sm">
                    <i class="fa fa-clipboard-list fa-2x text-warning mb-2 d-block"></i>
                    <small>Bookings</small>
                </div>
            </a>
        </div>
        <div class="col-md-2 col-4 text-center">
            <a href="ParkingCost.jsp" class="text-decoration-none">
                <div class="p-3 border rounded bg-white shadow-sm">
                    <i class="fa fa-rupee-sign fa-2x text-danger mb-2 d-block"></i>
                    <small>Parking Cost</small>
                </div>
            </a>
        </div>
        <div class="col-md-2 col-4 text-center">
            <a href="ParkingLogs.jsp" class="text-decoration-none">
                <div class="p-3 border rounded bg-white shadow-sm">
                    <i class="fa fa-history fa-2x text-info mb-2 d-block"></i>
                    <small>Parking Logs</small>
                </div>
            </a>
        </div>
    </div>

    <!-- Recent Bookings -->
    <div class="form-card">
        <h5 class="fw-bold mb-3"><i class="fa fa-clock me-2 text-danger"></i>Recent Bookings</h5>
        <div class="table-responsive">
            <table class="data-table">
                <tr>
                    <th>#</th><th>User</th><th>Vehicle No.</th><th>Date</th>
                    <th>Slot</th><th>Cost</th><th>Status</th>
                </tr>
                <%
                try (Connection con2 = DBConnection.getConnection();
                     ResultSet rs2 = con2.createStatement().executeQuery(
                         "SELECT * FROM slot_booking ORDER BY id DESC LIMIT 10")) {
                    int idx = 1;
                    while (rs2.next()) {
                        String st = rs2.getString("ustatus");
                        String badgeClass = "Used".equals(st) ? "badge-used" : "Pending".equals(st) ? "badge-pending" : "badge-cancelled";
                %>
                <tr>
                    <td><%= idx++ %></td>
                    <td><%= rs2.getString("uname") %></td>
                    <td><strong><%= rs2.getString("vehicle_number") %></strong></td>
                    <td><%= rs2.getString("pdate") %></td>
                    <td><%= rs2.getString("slot_name") %></td>
                    <td>&#8377;<%= rs2.getString("pcost") %></td>
                    <td><span class="badge <%= badgeClass %>"><%= st %></span></td>
                </tr>
                <% } } catch(Exception e){ e.printStackTrace(); } %>
            </table>
        </div>
    </div>
</div>

<div class="footer pt-4 pb-3 mt-5">
    <div class="container text-center">
        <p class="mb-0">&copy; 2024 QR Smart Vehicle Parking. All rights reserved.</p>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
