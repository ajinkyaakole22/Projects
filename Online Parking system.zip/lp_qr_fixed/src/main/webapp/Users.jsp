<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head><%@include file="WEB-INF/header.jspf"%></head>
<body>
<% if (request.getParameter("Failed") != null) { %>
<script>window.onload = function(){ alert('Invalid email or password. Please try again.'); }</script>
<% } %>
<% if (request.getParameter("Registered") != null) { %>
<script>window.onload = function(){ alert('Registration successful! Please login.'); }</script>
<% } %>

<nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
    <a href="index.jsp" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <img src="img/logo.png" alt="QR Smart Parking" height="42">
    </a>
    <button class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="index.jsp" class="nav-item nav-link">Home</a>
            <a href="Administrator.jsp" class="nav-item nav-link">Administrator</a>
            <a href="Users.jsp" class="nav-item nav-link active">User Login</a>
            <a href="Register.jsp" class="nav-item nav-link">Register</a>
        </div>
    </div>
</nav>

<div class="page-header">
    <div class="container text-center py-4">
        <h1><i class="fa fa-user me-2"></i>User Login</h1>
    </div>
</div>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="form-card">
                <h4 class="text-center mb-4"><i class="fa fa-sign-in-alt me-2 text-danger"></i>Login to Your Account</h4>
                <form action="Userlog" method="post">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Email Address</label>
                        <input type="email" class="form-control form-control-lg" name="email"
                               placeholder="Enter your email" required>
                    </div>
                    <div class="mb-4">
                        <label class="form-label fw-semibold">Password</label>
                        <input type="password" class="form-control form-control-lg" name="pass"
                               placeholder="Enter password" required>
                    </div>
                    <button type="submit" class="btn btn-danger w-100 btn-lg">
                        <i class="fa fa-sign-in-alt me-2"></i>Login
                    </button>
                </form>
                <hr class="my-3">
                <p class="text-center text-muted">Don't have an account?
                    <a href="Register.jsp" class="text-danger fw-semibold">Register Here</a>
                </p>
            </div>
        </div>
    </div>
</div>

<div class="footer pt-4 pb-3 mt-5"><div class="container text-center">
    <p class="mb-0">&copy; 2024 QR Smart Vehicle Parking. All rights reserved.</p>
</div></div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
