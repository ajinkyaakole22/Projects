<%@page import="com.qrparking.util.DBConnection"%>
<%@page import="java.sql.*"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    HttpSession sess = request.getSession(false);
    if (sess == null || !"user".equals(sess.getAttribute("role"))) {
        response.sendRedirect("Users.jsp?Failed"); return;
    }
    String userName = (String) sess.getAttribute("userName");
    int userId = (int) sess.getAttribute("userId");

    int myBookings = 0, myVehicles = 0;
    try (Connection con = DBConnection.getConnection()) {
        // FIX: Use PreparedStatement instead of raw string concatenation
        PreparedStatement ps1 = con.prepareStatement("SELECT COUNT(*) FROM slot_booking WHERE uid=?");
        ps1.setString(1, String.valueOf(userId));
        ResultSet r = ps1.executeQuery(); r.next(); myBookings = r.getInt(1);

        PreparedStatement ps2 = con.prepareStatement("SELECT COUNT(*) FROM vehicle_details WHERE user_id=?");
        ps2.setInt(1, userId);
        r = ps2.executeQuery(); r.next(); myVehicles = r.getInt(1);
    } catch (Exception e) { e.printStackTrace(); }
%>
<!DOCTYPE html>
<html lang="en">
<head><%@include file="WEB-INF/header.jspf"%></head>
<body>
<nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
    <a href="UserHome.jsp" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <img src="img/logo.png" alt="QR Smart Parking" height="42">
    </a>
    <button class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="UserHome.jsp" class="nav-item nav-link active">Home</a>
            <a href="MyVehicles.jsp" class="nav-item nav-link">My Vehicles</a>
            <a href="parking_cost1.jsp" class="nav-item nav-link">Parking Cost</a>
            <a href="Book_parking.jsp" class="nav-item nav-link">Book Slot</a>
            <a href="your_bookings.jsp" class="nav-item nav-link">My Bookings</a>
            <a href="logout" class="nav-item nav-link text-danger">Logout</a>
        </div>
    </div>
</nav>

<div class="page-header">
    <div class="container py-3">
        <h2>Welcome, <strong><%= userName %></strong>! 👋</h2>
        <p class="mb-0">Manage your parking reservations and vehicles</p>
    </div>
</div>

<div class="container py-4">
    <div class="row g-4 mb-4">
        <div class="col-md-4 col-6">
            <div class="stat-card bg-info">
                <div class="stat-number"><%= myVehicles %></div>
                <div class="stat-label"><i class="fa fa-car me-1"></i>My Vehicles</div>
            </div>
        </div>
        <div class="col-md-4 col-6">
            <div class="stat-card bg-warning">
                <div class="stat-number"><%= myBookings %></div>
                <div class="stat-label"><i class="fa fa-calendar-check me-1"></i>My Bookings</div>
            </div>
        </div>
        <div class="col-md-4 col-12">
            <a href="Book_parking.jsp" class="text-decoration-none">
                <div class="stat-card bg-danger">
                    <div class="stat-number"><i class="fa fa-plus-circle"></i></div>
                    <div class="stat-label">Book New Slot</div>
                </div>
            </a>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-md-6">
            <div class="form-card h-100">
                <h5 class="fw-bold mb-3"><i class="fa fa-car me-2 text-danger"></i>My Vehicles</h5>
                <%
                try (Connection con = DBConnection.getConnection();
                     PreparedStatement ps = con.prepareStatement(
                         "SELECT * FROM vehicle_details WHERE user_id=? ORDER BY is_default DESC LIMIT 3");) {
                    ps.setInt(1, userId);
                    ResultSet rs = ps.executeQuery();
                    boolean any = false;
                    while (rs.next()) {
                        any = true;
                        String icon = "Car".equals(rs.getString("vehicle_type")) ? "🚗" :
                                      "Bike".equals(rs.getString("vehicle_type")) ? "🏍" :
                                      "SUV".equals(rs.getString("vehicle_type")) ? "🚙" : "🚛";
                %>
                <div class="d-flex align-items-center mb-3 p-2 border rounded">
                    <span style="font-size:1.8rem;margin-right:12px"><%= icon %></span>
                    <div>
                        <strong><%= rs.getString("vehicle_number") %></strong>
                        <% if (rs.getInt("is_default") == 1) { %><span class="badge bg-success ms-1" style="font-size:0.7rem">Default</span><% } %>
                        <div class="text-muted small"><%= rs.getString("vehicle_brand") %> <%= rs.getString("vehicle_model") %> • <%= rs.getString("vehicle_color") %></div>
                    </div>
                </div>
                <% }
                    if (!any) { %>
                <p class="text-muted">No vehicles added yet.</p>
                <% } } catch(Exception e){ e.printStackTrace(); } %>
                <a href="MyVehicles.jsp" class="btn btn-outline-danger btn-sm mt-2">Manage Vehicles</a>
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-card h-100">
                <h5 class="fw-bold mb-3"><i class="fa fa-clock me-2 text-danger"></i>Recent Bookings</h5>
                <%
                try (Connection con = DBConnection.getConnection();
                     PreparedStatement ps2 = con.prepareStatement(
                         "SELECT * FROM slot_booking WHERE uid=? ORDER BY id DESC LIMIT 3")) {
                    ps2.setString(1, String.valueOf(userId));
                    ResultSet rs2 = ps2.executeQuery();
                    boolean any2 = false;
                    while (rs2.next()) {
                        any2 = true;
                        String st = rs2.getString("ustatus");
                        String badge = "Used".equals(st) ? "bg-success" : "bg-warning text-dark";
                %>
                <div class="d-flex justify-content-between align-items-center mb-3 p-2 border rounded">
                    <div>
                        <strong><%= rs2.getString("slot_name") %></strong>
                        <div class="text-muted small"><%= rs2.getString("pdate") %> • <%= rs2.getString("vehicle_number") %></div>
                    </div>
                    <div class="text-end">
                        <div>&#8377;<%= rs2.getString("pcost") %></div>
                        <span class="badge <%= badge %>"><%= st %></span>
                    </div>
                </div>
                <% }
                    if (!any2) { %>
                <p class="text-muted">No bookings yet.</p>
                <% } } catch(Exception e){ e.printStackTrace(); } %>
                <a href="your_bookings.jsp" class="btn btn-outline-danger btn-sm mt-2">View All Bookings</a>
            </div>
        </div>
    </div>
</div>

<div class="footer pt-4 pb-3 mt-5"><div class="container text-center">
    <p class="mb-0">&copy; 2024 QR Smart Vehicle Parking. All rights reserved.</p>
</div></div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
