<%@page import="com.qrparking.util.DBConnection"%>
<%@page import="java.sql.*"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    // FIX: Added session check - page was completely unprotected
    HttpSession verSess = request.getSession(false);
    String verRole = (verSess != null) ? (String) verSess.getAttribute("role") : null;
    if (verSess == null || (!"admin".equals(verRole) && !"ticketchecker".equals(verRole))) {
        response.sendRedirect("index.jsp"); return;
    }
    String id = request.getParameter("id");
    String uname="", pdate="", stime="", endtime="", slotName="", pcost="", vehicleNum="", vehicleType="";
    if (id != null) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement("SELECT * FROM slot_booking WHERE id=?")) {
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                uname=rs.getString("uname"); pdate=rs.getString("pdate");
                stime=rs.getString("stime"); endtime=rs.getString("endtime");
                slotName=rs.getString("slot_name"); pcost=rs.getString("pcost");
                vehicleNum=rs.getString("vehicle_number"); vehicleType=rs.getString("vehicle_type");
            }
        } catch(Exception e){ e.printStackTrace(); }
    }
    String stF=stime, etF=endtime;
    try { SimpleDateFormat f24=new SimpleDateFormat("HH:mm:ss"),f12=new SimpleDateFormat("hh:mm a");
          stF=f12.format(f24.parse(stime)); etF=f12.format(f24.parse(endtime)); } catch(Exception e){}
%>
<!DOCTYPE html>
<html lang="en">
<head><%@include file="WEB-INF/header.jspf"%></head>
<body>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-6 text-center">
            <div class="mb-4">
                <div style="font-size:4rem;color:#28a745">✅</div>
                <h2 class="text-success fw-bold">Ticket Verified!</h2>
                <p class="text-muted">Vehicle cleared for parking entry</p>
            </div>
            <div class="form-card text-start">
                <h5 class="fw-bold mb-3 text-danger"><i class="fa fa-info-circle me-2"></i>Booking Details</h5>
                <table class="table table-borderless">
                    <tr><td class="fw-semibold">Name:</td><td><%= uname %></td></tr>
                    <tr><td class="fw-semibold">Vehicle No.:</td><td><strong class="text-danger"><%= vehicleNum %></strong></td></tr>
                    <tr><td class="fw-semibold">Vehicle Type:</td><td><%= vehicleType %></td></tr>
                    <tr><td class="fw-semibold">Date:</td><td><%= pdate %></td></tr>
                    <tr><td class="fw-semibold">Entry:</td><td><%= stF %></td></tr>
                    <tr><td class="fw-semibold">Exit:</td><td><%= etF %></td></tr>
                    <tr><td class="fw-semibold">Slot:</td><td><strong class="text-primary"><%= slotName %></strong></td></tr>
                    <tr><td class="fw-semibold">Amount:</td><td>&#8377;<%= pcost %></td></tr>
                </table>
            </div>
            <div class="mt-4">
                <a href="CheckParking.jsp" class="btn btn-danger btn-lg me-2">
                    <i class="fa fa-qrcode me-2"></i>Scan Next
                </a>
                <a href="ParkingLogs.jsp" class="btn btn-outline-secondary btn-lg">View Logs</a>
            </div>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
