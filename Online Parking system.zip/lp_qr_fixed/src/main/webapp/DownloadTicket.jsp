<%@page import="com.qrparking.util.DBConnection"%>
<%@page import="java.sql.*"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.net.URLEncoder"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    HttpSession sess = request.getSession(false);
    if (sess == null || !"user".equals(sess.getAttribute("role"))) {
        response.sendRedirect("Users.jsp?Failed"); return;
    }
    String reqid = request.getParameter("reqid");
    if (reqid == null) { response.sendRedirect("your_bookings.jsp"); return; }

    String uname="", pdate="", stime="", endtime="", slotName="", pcost="",
           vehicleNum="", vehicleType="", paymentMode="", codeVal="", phrs="";

    try (Connection con = DBConnection.getConnection();
         PreparedStatement ps = con.prepareStatement("SELECT * FROM slot_booking WHERE id=?")) {
        ps.setString(1, reqid);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            uname       = rs.getString("uname");
            pdate       = rs.getString("pdate");
            stime       = rs.getString("stime");
            endtime     = rs.getString("endtime");
            slotName    = rs.getString("slot_name");
            pcost       = rs.getString("pcost");
            vehicleNum  = rs.getString("vehicle_number");
            vehicleType = rs.getString("vehicle_type");
            paymentMode = rs.getString("payment_mode");
            codeVal     = rs.getString("codeval");
            phrs        = rs.getString("phrs");
        }
    } catch(Exception e){ e.printStackTrace(); }

    // Format times to 12-hour
    String stimeFormatted = stime, etimeFormatted = endtime;
    try {
        SimpleDateFormat f24 = new SimpleDateFormat("HH:mm:ss");
        SimpleDateFormat f12 = new SimpleDateFormat("hh:mm a");
        stimeFormatted = f12.format(f24.parse(stime));
        etimeFormatted = f12.format(f24.parse(endtime));
    } catch(Exception e){}

    // ---------------------------------------------------------------
    // QR Code: rich parking info encoded as plain text lines
    // Uses api.qrserver.com - free, no API key, never deprecated
    // ---------------------------------------------------------------
    String qrData = "QR SMART PARKING\n"
                  + "================\n"
                  + "Booking ID : #" + reqid + "\n"
                  + "Code       : " + codeVal + "\n"
                  + "Name       : " + uname + "\n"
                  + "Vehicle    : " + vehicleNum + " (" + vehicleType + ")\n"
                  + "Date       : " + pdate + "\n"
                  + "Entry      : " + stimeFormatted + "\n"
                  + "Exit       : " + etimeFormatted + "\n"
                  + "Duration   : " + phrs + " hr(s)\n"
                  + "Slot       : " + slotName + "\n"
                  + "Amount     : Rs." + pcost + "\n"
                  + "Payment    : " + paymentMode + "\n"
                  + "Status     : VALID";

    // api.qrserver.com — free public API, no key required
    String qrUrl = "https://api.qrserver.com/v1/create-qr-code/"
                 + "?size=180x180"
                 + "&margin=10"
                 + "&color=0B2154"
                 + "&bgcolor=FFFFFF"
                 + "&ecc=M"
                 + "&data=" + URLEncoder.encode(qrData, "UTF-8");
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <%@include file="WEB-INF/header.jspf"%>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <style>
        /* ---- Ticket QR section ---- */
        .ticket-qr {
            text-align: center;
            padding-left: 24px;
            min-width: 200px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        .qr-box {
            background: #fff;
            border: 3px solid #0B2154;
            border-radius: 10px;
            padding: 8px;
            display: inline-block;
            box-shadow: 0 2px 12px rgba(11,33,84,0.15);
        }
        .qr-box img {
            display: block;
            width: 180px;
            height: 180px;
        }
        .qr-label {
            font-size: 0.72rem;
            color: #555;
            margin-top: 8px;
            font-weight: 600;
            letter-spacing: 0.5px;
            text-transform: uppercase;
        }
        .qr-code-text {
            font-size: 0.62rem;
            color: #999;
            font-family: monospace;
            margin-top: 4px;
            letter-spacing: 1px;
        }
        /* QR loading spinner */
        .qr-loading {
            width: 180px; height: 180px;
            display: flex; align-items: center; justify-content: center;
            border: 3px dashed #ccc; border-radius: 10px;
            color: #aaa; font-size: 0.8rem; flex-direction: column; gap: 8px;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
    <a href="UserHome.jsp" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <img src="img/logo.png" alt="QR Smart Parking" height="42">
    </a>
    <div class="collapse navbar-collapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="UserHome.jsp"      class="nav-item nav-link">Home</a>
            <a href="Book_parking.jsp"  class="nav-item nav-link">Book Slot</a>
            <a href="your_bookings.jsp" class="nav-item nav-link">My Bookings</a>
            <a href="logout"            class="nav-item nav-link text-danger">Logout</a>
        </div>
    </div>
</nav>

<div class="page-header"><div class="container py-3">
    <h2><i class="fa fa-ticket-alt me-2"></i>Booking Confirmed!</h2>
    <p class="mb-0">Your parking ticket is ready. Download and show QR code at the gate.</p>
</div></div>

<div class="container py-4">

    <!-- Step indicator: all green -->
    <div class="d-flex align-items-center mb-4">
        <div class="rounded-circle bg-success text-white d-flex align-items-center justify-content-center"
             style="width:36px;height:36px;font-weight:700">&#10003;</div>
        <div style="height:2px;width:60px;background:#28a745;margin:0 8px"></div>
        <div class="rounded-circle bg-success text-white d-flex align-items-center justify-content-center"
             style="width:36px;height:36px;font-weight:700">&#10003;</div>
        <div style="height:2px;width:60px;background:#28a745;margin:0 8px"></div>
        <div class="rounded-circle bg-success text-white d-flex align-items-center justify-content-center"
             style="width:36px;height:36px;font-weight:700">&#10003;</div>
    </div>

    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-7">

            <!-- ===== TICKET ===== -->
            <div class="parking-ticket" id="ticketContent">

                <!-- Header -->
                <div class="ticket-header">
                    <div>
                        <h4 class="mb-0"><i class="fa fa-qrcode me-2"></i>Parking Ticket</h4>
                        <small>QR Smart Vehicle Parking</small>
                    </div>
                    <div class="text-end">
                        <div style="font-size:1.5rem;font-weight:700">#<%= reqid %></div>
                        <small>Booking ID</small>
                    </div>
                </div>

                <!-- Body: info + QR -->
                <div class="ticket-body">

                    <!-- Left: booking details -->
                    <div class="ticket-info">
                        <p><strong>Name:</strong> <%= uname %></p>
                        <p><strong>Vehicle No.:</strong>
                           <span style="color:#D81324;font-weight:700"><%= vehicleNum %></span></p>
                        <p><strong>Vehicle Type:</strong> <%= vehicleType %></p>
                        <p><strong>Date:</strong> <%= pdate %></p>
                        <p><strong>Entry:</strong> <%= stimeFormatted %></p>
                        <p><strong>Exit:</strong>  <%= etimeFormatted %></p>
                        <p><strong>Duration:</strong> <%= phrs %> hr(s)</p>
                        <p><strong>Slot:</strong>
                           <span style="color:#0B2154;font-weight:700"><%= slotName %></span></p>
                        <p><strong>Amount:</strong> &#8377;<%= pcost %></p>
                        <p><strong>Payment:</strong> <%= paymentMode %></p>
                    </div>

                    <!-- Right: QR code from api.qrserver.com -->
                    <div class="ticket-qr">
                        <!-- Loading placeholder shown while QR loads -->
                        <div class="qr-loading" id="qrLoading">
                            <i class="fa fa-spinner fa-spin fa-2x"></i>
                            <span>Loading QR...</span>
                        </div>

                        <!-- Actual QR image (hidden until loaded) -->
                        <div class="qr-box" id="qrBox" style="display:none">
                            <img id="qrImg"
                                 src="<%= qrUrl %>"
                                 alt="QR Code"
                                 onload="qrLoaded()"
                                 onerror="qrFailed()">
                        </div>

                        <div class="qr-label" id="qrScanLabel" style="display:none">
                            <i class="fa fa-qrcode me-1"></i> Scan at Gate
                        </div>
                        <div class="qr-code-text" id="qrCodeText" style="display:none">
                            <%= codeVal %>
                        </div>
                    </div>
                </div>

                <!-- Footer -->
                <div class="ticket-footer">
                    <i class="fa fa-info-circle me-1"></i>
                    Please arrive on time. Ticket valid for selected slot only.
                    Show QR code at parking gate for entry.
                </div>
            </div><!-- /.parking-ticket -->

            <!-- Action buttons -->
            <div class="text-center mt-4">
                <button class="btn btn-success btn-lg me-3" id="downloadBtn">
                    <i class="fa fa-download me-2"></i>Download Ticket
                </button>
                <a href="your_bookings.jsp" class="btn btn-outline-secondary btn-lg">
                    <i class="fa fa-list me-2"></i>My Bookings
                </a>
            </div>

            <!-- Info card about what QR contains -->
            <div class="alert alert-info mt-4" style="border-radius:10px;">
                <h6 class="fw-bold mb-2"><i class="fa fa-info-circle me-2"></i>What is in the QR Code?</h6>
                <p class="mb-0 small">
                    The QR code contains your complete booking details — Booking ID <strong>#<%= reqid %></strong>,
                    unique code <strong><%= codeVal %></strong>, vehicle <strong><%= vehicleNum %></strong>,
                    slot <strong><%= slotName %></strong>, date <strong><%= pdate %></strong>,
                    entry <strong><%= stimeFormatted %></strong> and exit <strong><%= etimeFormatted %></strong>.
                    The parking attendant scans this QR to verify and grant entry.
                </p>
            </div>

        </div>
    </div>
</div>

<div class="footer pt-4 pb-3 mt-5"><div class="container text-center">
    <p class="mb-0">&copy; 2024 QR Smart Vehicle Parking. All rights reserved.</p>
</div></div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Show QR when image loads successfully
    function qrLoaded() {
        document.getElementById('qrLoading').style.display = 'none';
        document.getElementById('qrBox').style.display     = 'inline-block';
        document.getElementById('qrScanLabel').style.display = 'block';
        document.getElementById('qrCodeText').style.display  = 'block';
    }

    // Fallback: if api.qrserver.com fails, use goqr.me as backup
    function qrFailed() {
        var fallbackUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=180x180&data='
                        + encodeURIComponent('<%= codeVal %>|#<%= reqid %>|<%= slotName %>|<%= pdate %>');
        var img = document.getElementById('qrImg');
        // Try fallback only once to avoid infinite loop
        if (!img.dataset.retried) {
            img.dataset.retried = '1';
            img.src = fallbackUrl;
        } else {
            document.getElementById('qrLoading').innerHTML =
                '<i class="fa fa-exclamation-circle fa-2x text-warning"></i>' +
                '<span>QR unavailable<br><small>Check internet</small></span>';
        }
    }

    // Download ticket as PNG using html2canvas
    document.getElementById('downloadBtn').addEventListener('click', function() {
        // Make sure QR is visible before capturing
        var qrImg = document.getElementById('qrImg');
        if (!qrImg.complete || qrImg.naturalWidth === 0) {
            alert('Please wait for the QR code to load before downloading.');
            return;
        }
        html2canvas(document.getElementById('ticketContent'), {
            scale: 2,
            useCORS: true,        // needed so html2canvas can capture the QR image from external domain
            allowTaint: false,
            logging: false
        }).then(function(canvas) {
            var link = document.createElement('a');
            link.download = 'Parking_Ticket_<%= reqid %>.png';
            link.href = canvas.toDataURL('image/png');
            link.click();
        });
    });
</script>
</body>
</html>
