<%@page import="com.qrparking.util.DBConnection"%>
<%@page import="java.sql.*"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    HttpSession sess = request.getSession(false);
    if (sess == null || !"admin".equals(sess.getAttribute("role"))) {
        response.sendRedirect("Administrator.jsp?Failed"); return;
    }
%>
<!DOCTYPE html>
<html lang="en">
<head><%@include file="WEB-INF/header.jspf"%></head>
<body>
<nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
    <a href="AdminHome.jsp" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <img src="img/logo.png" alt="QR Smart Parking" height="42">
    </a>
    <button class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="AdminHome.jsp" class="nav-item nav-link">Dashboard</a>
            <a href="UserDetails.jsp" class="nav-item nav-link active">Users</a>
            <a href="VehicleDetails.jsp" class="nav-item nav-link">Vehicles</a>
            <a href="ParkingCost.jsp" class="nav-item nav-link">Parking Cost</a>
            <a href="Bookings.jsp" class="nav-item nav-link">Bookings</a>
            <a href="ParkingLogs.jsp" class="nav-item nav-link">Parking Logs</a>
            <a href="logout" class="nav-item nav-link text-danger">Logout</a>
        </div>
    </div>
</nav>
<div class="page-header"><div class="container py-3">
    <h2><i class="fa fa-users me-2"></i>Registered Users</h2>
</div></div>
<div class="container py-4">
    <div class="form-card">
        <div class="mb-3">
            <input type="text" id="searchInput" class="form-control" placeholder="Search users..." style="max-width:350px">
        </div>
        <div class="table-responsive">
            <table class="data-table" id="userTable">
                <tr>
                    <th>#</th><th>Name</th><th>Email</th><th>Phone</th>
                    <th>Gender</th><th>Registered On</th><th>Vehicles</th>
                </tr>
                <%
                try (Connection con = DBConnection.getConnection();
                     ResultSet rs = con.createStatement().executeQuery(
                         "SELECT u.*, (SELECT COUNT(*) FROM vehicle_details v WHERE v.user_id=u.id) AS vcount " +
                         "FROM user_reg u ORDER BY u.id DESC")) {
                    int i = 1;
                    while (rs.next()) {
                %>
                <tr>
                    <td><%= i++ %></td>
                    <td><strong><%= rs.getString("name") %></strong></td>
                    <td><%= rs.getString("email") %></td>
                    <td><%= rs.getString("phone") %></td>
                    <td><%= rs.getString("gender") %></td>
                    <td><%= rs.getString("created_at") %></td>
                    <td><span class="badge bg-info"><%= rs.getInt("vcount") %> vehicle(s)</span></td>
                </tr>
                <% } } catch(Exception e){ e.printStackTrace(); } %>
            </table>
        </div>
    </div>
</div>
<div class="footer pt-4 pb-3 mt-5"><div class="container text-center">
    <p class="mb-0">&copy; 2024 QR Smart Vehicle Parking. All rights reserved.</p>
</div></div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.getElementById('searchInput').addEventListener('keyup', function() {
        var s = this.value.toLowerCase();
        document.querySelectorAll('#userTable tr:not(:first-child)').forEach(function(r) {
            r.style.display = r.innerText.toLowerCase().includes(s) ? '' : 'none';
        });
    });
</script>
</body>
</html>
