<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <%@include file="WEB-INF/header.jspf"%>
    <style>
        /* Hero uses parking-hero.jpg with dark overlay */
        .hero {
            background: linear-gradient(rgba(11,33,84,0.75), rgba(0,0,0,0.70)),
                        url('img/parking-hero.jpg') center center / cover no-repeat;
            color: #fff;
            padding: 100px 0;
            min-height: 480px;
            display: flex;
            align-items: center;
        }
        .hero h1 { font-size: 2.8rem; font-weight: 700; text-shadow: 0 2px 8px rgba(0,0,0,0.5); }
        .hero p.lead { text-shadow: 0 1px 4px rgba(0,0,0,0.4); }
        .feature-icon { font-size: 2.5rem; color: #D81324; }
        .feature-card { border-radius: 12px; padding: 28px; border: 1px solid #eee; height: 100%; transition: all .2s; background:#fff; }
        .feature-card:hover { box-shadow: 0 4px 20px rgba(0,0,0,0.1); transform: translateY(-3px); }
        /* About section */
        .about-img { width: 100%; border-radius: 14px; box-shadow: 0 6px 30px rgba(0,0,0,0.15); object-fit: cover; max-height: 360px; }
    </style>
</head>
<body>

<!-- Navbar with logo image -->
<nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
    <a href="index.jsp" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <img src="img/logo.png" alt="QR Smart Parking" height="42" class="me-2">
    </a>
    <button class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="index.jsp"       class="nav-item nav-link active">Home</a>
            <a href="Administrator.jsp" class="nav-item nav-link">Admin Login</a>
            <a href="Users.jsp"       class="nav-item nav-link">User Login</a>
            <a href="Register.jsp"    class="nav-item nav-link">Register</a>
        </div>
    </div>
</nav>

<!-- Hero Section — uses parking-hero.jpg -->
<div class="hero">
    <div class="container text-center w-100">
        <h1><i class="fa fa-qrcode me-3"></i>QR Code-Based Smart Vehicle Parking</h1>
        <p class="lead mt-3">Book parking slots instantly. Get your QR ticket. Hassle-free entry &amp; exit.</p>
        <div class="mt-4">
            <a href="Register.jsp" class="btn btn-light btn-lg me-3"><i class="fa fa-user-plus me-2"></i>Get Started</a>
            <a href="Users.jsp"    class="btn btn-outline-light btn-lg"><i class="fa fa-sign-in-alt me-2"></i>Login</a>
        </div>
    </div>
</div>

<!-- About Section — uses about.jpg + pexels banner -->
<div class="container py-5">
    <div class="row align-items-center g-5">
        <div class="col-md-6">
            <img src="img/about.jpg" alt="Smart Parking" class="about-img">
        </div>
        <div class="col-md-6">
            <h6 class="text-danger text-uppercase fw-bold">// About //</h6>
            <h2 class="fw-bold mb-3">Smart Parking for the Modern City</h2>
            <p class="text-muted">Our QR-based parking system eliminates the hassle of manual ticketing. Register your vehicle, book a slot in seconds, and receive a unique QR code ticket. Entry and exit are fully contactless — just scan and go.</p>
            <p class="text-muted mb-4">Designed for both individual users and parking administrators, the system gives real-time slot visibility, full booking history, and live revenue tracking.</p>
            <a href="Register.jsp" class="btn btn-danger btn-lg"><i class="fa fa-user-plus me-2"></i>Register Free</a>
        </div>
    </div>
</div>

<!-- Features -->
<div class="bg-light py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h6 class="text-danger text-uppercase fw-bold">// Features //</h6>
            <h2 class="fw-bold">Why Choose QR Smart Parking?</h2>
        </div>
        <div class="row g-4">
            <div class="col-md-4">
                <div class="feature-card text-center">
                    <div class="feature-icon mb-3"><i class="fa fa-qrcode"></i></div>
                    <h5>QR-Based Entry</h5>
                    <p class="text-muted">Get a unique QR code ticket for each booking. Quick scan for contactless entry and exit.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="feature-card text-center">
                    <div class="feature-icon mb-3"><i class="fa fa-calendar-check"></i></div>
                    <h5>Advance Booking</h5>
                    <p class="text-muted">Book your parking slot in advance and choose your preferred time slot and duration.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="feature-card text-center">
                    <div class="feature-icon mb-3"><i class="fa fa-car"></i></div>
                    <h5>Multi-Vehicle Support</h5>
                    <p class="text-muted">Register multiple vehicles (Car, Bike, SUV, Truck) and manage them from one account.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="feature-card text-center">
                    <div class="feature-icon mb-3"><i class="fa fa-map-marked-alt"></i></div>
                    <h5>Visual Slot Map</h5>
                    <p class="text-muted">See real-time availability of 30 parking slots on an interactive map before booking.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="feature-card text-center">
                    <div class="feature-icon mb-3"><i class="fa fa-download"></i></div>
                    <h5>Downloadable Ticket</h5>
                    <p class="text-muted">Download your parking ticket as an image. Show QR at the gate for entry.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="feature-card text-center">
                    <div class="feature-icon mb-3"><i class="fa fa-chart-bar"></i></div>
                    <h5>Admin Dashboard</h5>
                    <p class="text-muted">Full admin control over bookings, users, parking costs, and real-time parking logs.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- How It Works — uses carousel-bg-2.jpg as background strip -->
<div style="background: linear-gradient(rgba(11,33,84,0.88),rgba(11,33,84,0.88)), url('img/carousel-bg-2.jpg') center/cover no-repeat; color:#fff;" class="py-5">
    <div class="container">
        <div class="text-center mb-4">
            <h6 class="text-warning text-uppercase fw-bold">// Process //</h6>
            <h2 class="fw-bold text-white">How It Works</h2>
        </div>
        <div class="row text-center g-4">
            <div class="col-md-3">
                <div class="rounded-circle bg-danger text-white d-inline-flex align-items-center justify-content-center mb-3" style="width:60px;height:60px;font-size:1.5rem;font-weight:700">1</div>
                <h6 class="text-white">Register &amp; Add Vehicle</h6>
                <p class="small" style="color:rgba(255,255,255,0.7)">Create account and add your vehicle details</p>
            </div>
            <div class="col-md-3">
                <div class="rounded-circle bg-danger text-white d-inline-flex align-items-center justify-content-center mb-3" style="width:60px;height:60px;font-size:1.5rem;font-weight:700">2</div>
                <h6 class="text-white">Select Date &amp; Time</h6>
                <p class="small" style="color:rgba(255,255,255,0.7)">Choose parking date, start time and duration</p>
            </div>
            <div class="col-md-3">
                <div class="rounded-circle bg-danger text-white d-inline-flex align-items-center justify-content-center mb-3" style="width:60px;height:60px;font-size:1.5rem;font-weight:700">3</div>
                <h6 class="text-white">Book a Slot</h6>
                <p class="small" style="color:rgba(255,255,255,0.7)">Pick an available slot and confirm booking</p>
            </div>
            <div class="col-md-3">
                <div class="rounded-circle bg-danger text-white d-inline-flex align-items-center justify-content-center mb-3" style="width:60px;height:60px;font-size:1.5rem;font-weight:700">4</div>
                <h6 class="text-white">Get QR Ticket</h6>
                <p class="small" style="color:rgba(255,255,255,0.7)">Download ticket and show QR at parking gate</p>
            </div>
        </div>
    </div>
</div>

<!-- Banner strip — uses pexels-jose-espinal-1000633.jpg -->
<div style="background: linear-gradient(rgba(216,19,36,0.85),rgba(11,33,84,0.85)), url('img/pexels-jose-espinal-1000633.jpg') center/cover no-repeat; padding:60px 0; color:#fff; text-align:center;">
    <div class="container">
        <h2 class="fw-bold mb-3">Ready to Park Smarter?</h2>
        <p class="lead mb-4" style="opacity:0.9">Join hundreds of users who book their parking spot in advance and never worry about finding space.</p>
        <a href="Register.jsp" class="btn btn-light btn-lg px-5"><i class="fa fa-user-plus me-2"></i>Create Free Account</a>
    </div>
</div>

<!-- Footer -->
<div class="footer pt-4 pb-3">
    <div class="container text-center">
        <p class="mb-0">&copy; 2024 <strong>QR Smart Vehicle Parking</strong>. All rights reserved.</p>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
