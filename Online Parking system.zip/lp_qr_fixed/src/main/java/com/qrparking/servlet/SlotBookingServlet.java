package com.qrparking.servlet;

import com.qrparking.util.DBConnection;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import java.util.UUID;

public class SlotBookingServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect("Users.jsp?Failed");
            return;
        }

        String uname       = (String) session.getAttribute("userName");
        String umail       = (String) session.getAttribute("userEmail");
        int    uid         = (int)    session.getAttribute("userId");

        String pdate       = request.getParameter("pdate");
        String stime       = request.getParameter("stime");
        String phrs        = request.getParameter("phrs");
        String slotName    = request.getParameter("Slot");
        String totalCost   = request.getParameter("totalcost");
        String paymentMode = request.getParameter("certype");
        String vehicleNum  = request.getParameter("vehicle_number");
        String vehicleType = request.getParameter("vehicle_type");

        if (slotName == null || slotName.trim().isEmpty()) {
            response.sendRedirect("Book_parking.jsp?Already");
            return;
        }
        if (vehicleNum == null || vehicleNum.trim().isEmpty()) {
            response.sendRedirect("Book_parking.jsp?NoVehicle");
            return;
        }

        try (Connection con = DBConnection.getConnection()) {
            String stime1 = stime + ":00";
            String phrs2  = phrs  + ":00:00";

            SimpleDateFormat tf = new SimpleDateFormat("HH:mm:ss");
            tf.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date d1 = tf.parse(stime1);
            Date d2 = tf.parse(phrs2);
            String etime = tf.format(new Date(d1.getTime() + d2.getTime()));

            // Check slot availability
            PreparedStatement checkPs = con.prepareStatement(
                "SELECT id FROM slot_booking WHERE slot_name=? AND pdate=? " +
                "AND NOT (endtime <= ? OR stime >= ?)");
            checkPs.setString(1, slotName);
            checkPs.setString(2, pdate);
            checkPs.setString(3, stime1);
            checkPs.setString(4, etime);
            if (checkPs.executeQuery().next()) {
                response.sendRedirect("Bookparking.jsp?date=" + pdate +
                        "&stime=" + stime + "&phrs=" + phrs + "&Already");
                return;
            }

            String codeVal = UUID.randomUUID().toString().substring(0, 12).toUpperCase();

            // FIX: Added Statement.RETURN_GENERATED_KEYS so getGeneratedKeys() works
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO slot_booking (uname, uid, umail, vehicle_number, vehicle_type, " +
                "pdate, stime, endtime, phrs, slot_name, pcost, payment_mode, codeval, ustatus, booked_at) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', NOW())",
                Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, uname);
            ps.setString(2, String.valueOf(uid));
            ps.setString(3, umail);
            ps.setString(4, vehicleNum.trim().toUpperCase());
            ps.setString(5, vehicleType != null ? vehicleType : "Car");
            ps.setString(6, pdate);
            ps.setString(7, stime1);
            ps.setString(8, etime);
            ps.setString(9, phrs);
            ps.setString(10, slotName);
            ps.setString(11, totalCost);
            ps.setString(12, paymentMode != null ? paymentMode : "Cash");
            ps.setString(13, codeVal);
            ps.executeUpdate();

            ResultSet gk = ps.getGeneratedKeys();
            if (gk.next()) {
                response.sendRedirect("DownloadTicket.jsp?reqid=" + gk.getInt(1));
            } else {
                response.sendRedirect("your_bookings.jsp?Slot_booked");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("Book_parking.jsp?Error");
        }
    }
}
