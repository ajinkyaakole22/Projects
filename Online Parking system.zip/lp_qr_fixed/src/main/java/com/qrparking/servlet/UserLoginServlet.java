package com.qrparking.servlet;

import com.qrparking.util.DBConnection;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

public class UserLoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String pass  = request.getParameter("pass");

        if (email == null || pass == null || email.trim().isEmpty()) {
            response.sendRedirect("Users.jsp?Failed");
            return;
        }

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT * FROM user_reg WHERE email=? AND password=?")) {
            ps.setString(1, email.trim());
            ps.setString(2, pass.trim());
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                HttpSession session = request.getSession();
                session.setAttribute("userId",    rs.getInt("id"));
                session.setAttribute("userName",  rs.getString("name"));
                session.setAttribute("userEmail", rs.getString("email"));
                session.setAttribute("role",      "user");
                response.sendRedirect("UserHome.jsp?Success");
            } else {
                response.sendRedirect("Users.jsp?Failed");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("Users.jsp?Failed");
        }
    }
}
