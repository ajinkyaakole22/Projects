package com.qrparking.servlet;

import com.qrparking.util.DBConnection;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

public class UpdateParkingCostServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || !"admin".equals(session.getAttribute("role"))) {
            response.sendRedirect("Administrator.jsp?Failed");
            return;
        }

        String vehicleType = request.getParameter("vehicle_type");
        String costStr     = request.getParameter("cost_per_hour");

        if (costStr == null || costStr.trim().isEmpty()) {
            response.sendRedirect("ParkingCost.jsp?Failed");
            return;
        }

        try {
            int cost = Integer.parseInt(costStr.trim());
            if (cost < 0) throw new NumberFormatException("Negative cost");

            try (Connection con = DBConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement(
                         "UPDATE parking_cost SET cost_per_hour=? WHERE vehicle_type=?")) {
                ps.setInt(1, cost);
                ps.setString(2, vehicleType != null ? vehicleType : "Car");
                int rows = ps.executeUpdate();
                if (rows > 0) {
                    response.sendRedirect("ParkingCost.jsp?Cost_updated");
                } else {
                    response.sendRedirect("ParkingCost.jsp?Failed");
                }
            }
        } catch (NumberFormatException | SQLException e) {
            e.printStackTrace();
            response.sendRedirect("ParkingCost.jsp?Failed");
        }
    }
}
