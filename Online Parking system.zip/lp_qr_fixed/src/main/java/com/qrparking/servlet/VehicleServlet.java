package com.qrparking.servlet;

import com.qrparking.util.DBConnection;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

public class VehicleServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect("Users.jsp?Failed");
            return;
        }

        String action = request.getParameter("action");
        int userId = (int) session.getAttribute("userId");

        if ("add".equals(action)) {
            addVehicle(request, response, userId);
        } else if ("delete".equals(action)) {
            deleteVehicle(request, response, userId);
        } else if ("setDefault".equals(action)) {
            setDefaultVehicle(request, response, userId);
        } else {
            response.sendRedirect("MyVehicles.jsp?Error=invalid_action");
        }
    }

    private void addVehicle(HttpServletRequest request, HttpServletResponse response, int userId)
            throws IOException {
        String vehicleNumber = request.getParameter("vehicle_number");
        String vehicleType   = request.getParameter("vehicle_type");
        String vehicleBrand  = request.getParameter("vehicle_brand");
        String vehicleModel  = request.getParameter("vehicle_model");
        String vehicleColor  = request.getParameter("vehicle_color");

        if (vehicleNumber == null || vehicleNumber.trim().isEmpty()) {
            response.sendRedirect("MyVehicles.jsp?Error=missing_vehicle_number");
            return;
        }

        try (Connection con = DBConnection.getConnection()) {
            // Check duplicate vehicle number for this user
            PreparedStatement check = con.prepareStatement(
                    "SELECT id FROM vehicle_details WHERE user_id=? AND vehicle_number=?");
            check.setInt(1, userId);
            check.setString(2, vehicleNumber.trim().toUpperCase());
            ResultSet rs = check.executeQuery();
            if (rs.next()) {
                response.sendRedirect("MyVehicles.jsp?Error=vehicle_exists");
                return;
            }

            // Check if this is user's first vehicle (auto set default)
            PreparedStatement countPs = con.prepareStatement(
                    "SELECT COUNT(*) FROM vehicle_details WHERE user_id=?");
            countPs.setInt(1, userId);
            ResultSet countRs = countPs.executeQuery();
            int count = 0;
            if (countRs.next()) count = countRs.getInt(1);

            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO vehicle_details (user_id, vehicle_number, vehicle_type, vehicle_brand, vehicle_model, vehicle_color, is_default) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?)");
            ps.setInt(1, userId);
            ps.setString(2, vehicleNumber.trim().toUpperCase());
            ps.setString(3, vehicleType != null ? vehicleType : "Car");
            ps.setString(4, vehicleBrand != null ? vehicleBrand : "");
            ps.setString(5, vehicleModel != null ? vehicleModel : "");
            ps.setString(6, vehicleColor != null ? vehicleColor : "");
            ps.setInt(7, count == 0 ? 1 : 0);

            int rows = ps.executeUpdate();
            if (rows > 0) {
                response.sendRedirect("MyVehicles.jsp?Success=added");
            } else {
                response.sendRedirect("MyVehicles.jsp?Error=add_failed");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("MyVehicles.jsp?Error=db_error");
        }
    }

    private void deleteVehicle(HttpServletRequest request, HttpServletResponse response, int userId)
            throws IOException {
        String vehicleId = request.getParameter("vehicle_id");
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "DELETE FROM vehicle_details WHERE id=? AND user_id=?")) {
            ps.setString(1, vehicleId);
            ps.setInt(2, userId);
            ps.executeUpdate();
            response.sendRedirect("MyVehicles.jsp?Success=deleted");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("MyVehicles.jsp?Error=db_error");
        }
    }

    private void setDefaultVehicle(HttpServletRequest request, HttpServletResponse response, int userId)
            throws IOException {
        String vehicleId = request.getParameter("vehicle_id");
        try (Connection con = DBConnection.getConnection()) {
            // Clear existing default
            PreparedStatement clear = con.prepareStatement(
                    "UPDATE vehicle_details SET is_default=0 WHERE user_id=?");
            clear.setInt(1, userId);
            clear.executeUpdate();

            // Set new default
            PreparedStatement set = con.prepareStatement(
                    "UPDATE vehicle_details SET is_default=1 WHERE id=? AND user_id=?");
            set.setString(1, vehicleId);
            set.setInt(2, userId);
            set.executeUpdate();

            response.sendRedirect("MyVehicles.jsp?Success=default_set");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("MyVehicles.jsp?Error=db_error");
        }
    }
}
