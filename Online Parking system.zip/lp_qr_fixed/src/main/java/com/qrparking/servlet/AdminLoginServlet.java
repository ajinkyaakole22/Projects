package com.qrparking.servlet;

import com.qrparking.util.DBConnection;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

public class AdminLoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String pass = request.getParameter("pass");

        if (name == null || pass == null || name.trim().isEmpty() || pass.trim().isEmpty()) {
            response.sendRedirect("Administrator.jsp?Failed");
            return;
        }

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT * FROM admin WHERE name=? AND password=?")) {
            ps.setString(1, name.trim());
            ps.setString(2, pass.trim());
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                HttpSession session = request.getSession();
                session.setAttribute("adminName", rs.getString("name"));
                session.setAttribute("adminId", rs.getInt("id"));
                session.setAttribute("role", "admin");
                response.sendRedirect("AdminHome.jsp?Success");
            } else {
                response.sendRedirect("Administrator.jsp?Failed");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("Administrator.jsp?Failed");
        }
    }
}
