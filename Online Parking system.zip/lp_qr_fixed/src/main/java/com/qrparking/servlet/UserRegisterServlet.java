package com.qrparking.servlet;

import com.qrparking.util.DBConnection;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

public class UserRegisterServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name          = request.getParameter("name");
        String email         = request.getParameter("email");
        String dob           = request.getParameter("dob");
        String gender        = request.getParameter("gender");
        String phone         = request.getParameter("phone");
        String address       = request.getParameter("address");
        String pass          = request.getParameter("password");
        String vehicleNumber = request.getParameter("vehicle_number");
        String vehicleType   = request.getParameter("vehicle_type");
        String vehicleBrand  = request.getParameter("vehicle_brand");
        String vehicleModel  = request.getParameter("vehicle_model");
        String vehicleColor  = request.getParameter("vehicle_color");

        if (name==null||email==null||pass==null||name.trim().isEmpty()||email.trim().isEmpty()||pass.trim().isEmpty()) {
            response.sendRedirect("Register.jsp?Error=missing_fields"); return;
        }

        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement check = con.prepareStatement("SELECT id FROM user_reg WHERE email=?");
            check.setString(1, email.trim());
            if (check.executeQuery().next()) { response.sendRedirect("Register.jsp?Error=email_exists"); return; }

            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO user_reg (name, email, dob, gender, phone, address, password) VALUES (?,?,?,?,?,?,?)",
                Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, name.trim()); ps.setString(2, email.trim());
            ps.setString(3, dob!=null?dob:""); ps.setString(4, gender!=null?gender:"");
            ps.setString(5, phone!=null?phone:""); ps.setString(6, address!=null?address:"");
            ps.setString(7, pass.trim());
            if (ps.executeUpdate() <= 0) { response.sendRedirect("Register.jsp?Error=register_failed"); return; }

            ResultSet gk = ps.getGeneratedKeys();
            int newId = gk.next() ? gk.getInt(1) : 0;

            if (newId > 0 && vehicleNumber!=null && !vehicleNumber.trim().isEmpty()) {
                PreparedStatement vps = con.prepareStatement(
                    "INSERT INTO vehicle_details (user_id, vehicle_number, vehicle_type, vehicle_brand, vehicle_model, vehicle_color, is_default) VALUES (?,?,?,?,?,?,1)");
                vps.setInt(1, newId);
                vps.setString(2, vehicleNumber.trim().toUpperCase());
                vps.setString(3, vehicleType!=null&&!vehicleType.isEmpty()?vehicleType:"Car");
                vps.setString(4, vehicleBrand!=null?vehicleBrand:"");
                vps.setString(5, vehicleModel!=null?vehicleModel:"");
                vps.setString(6, vehicleColor!=null?vehicleColor:"");
                vps.executeUpdate();
            }
            response.sendRedirect("Users.jsp?Registered");
        } catch (SQLException e) { e.printStackTrace(); response.sendRedirect("Register.jsp?Error=db_error"); }
    }
}
