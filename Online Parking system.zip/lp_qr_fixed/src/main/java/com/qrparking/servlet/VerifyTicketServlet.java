package com.qrparking.servlet;

import com.qrparking.util.DBConnection;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

public class VerifyTicketServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        // FIX: Original had operator-precedence bug:
        //   session==null || !"ticketchecker".equals(role) && !"admin".equals(role)
        // && binds tighter than ||, so the null check was not properly guarding getAttribute().
        // Now role is read safely after null check.
        String role = (session != null) ? (String) session.getAttribute("role") : null;
        if (session == null || (!"ticketchecker".equals(role) && !"admin".equals(role))) {
            response.sendRedirect("index.jsp?Failed");
            return;
        }

        String qrValue = request.getParameter("qr");
        if (qrValue == null || qrValue.trim().isEmpty()) {
            response.sendRedirect("CheckParking.jsp?Invalid");
            return;
        }

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT * FROM slot_booking WHERE codeval=?")) {
            ps.setString(1, qrValue.trim());
            ResultSet rs = ps.executeQuery();

            if (!rs.next()) {
                response.sendRedirect("CheckParking.jsp?Invalid");
                return;
            }

            if ("Used".equals(rs.getString("ustatus"))) {
                response.sendRedirect("CheckParking.jsp?AlreadyUsed");
                return;
            }

            int bookingId = rs.getInt("id");

            PreparedStatement upd = con.prepareStatement(
                    "UPDATE slot_booking SET ustatus='Used' WHERE id=?");
            upd.setInt(1, bookingId);
            upd.executeUpdate();

            PreparedStatement logPs = con.prepareStatement(
                    "INSERT INTO parking_logs (booking_id, uname, vehicle_number, slot_name) VALUES (?,?,?,?)");
            logPs.setInt(1, bookingId);
            logPs.setString(2, rs.getString("uname"));
            logPs.setString(3, rs.getString("vehicle_number"));
            logPs.setString(4, rs.getString("slot_name"));
            logPs.executeUpdate();

            response.sendRedirect("VerifiedTicket.jsp?id=" + bookingId);

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("CheckParking.jsp?Invalid");
        }
    }
}
