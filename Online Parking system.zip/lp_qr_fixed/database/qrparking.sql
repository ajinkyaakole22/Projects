-- ============================================================
-- QR Code-Based Smart Vehicle Parking System - Database
-- ============================================================

CREATE DATABASE IF NOT EXISTS qrparking;
USE qrparking;

-- Admin table
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  `password` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `admin` (`name`, `password`) VALUES ('admin', 'admin123');

-- User registration table
-- FIX: dob, gender, phone, address are optional on the form but were NOT NULL with no DEFAULT
--      Added DEFAULT '' so empty submissions don't cause a DB error
DROP TABLE IF EXISTS `user_reg`;
CREATE TABLE `user_reg` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `dob` VARCHAR(45) NOT NULL DEFAULT '',
  `gender` VARCHAR(45) NOT NULL DEFAULT '',
  `phone` VARCHAR(15) NOT NULL DEFAULT '',
  `address` VARCHAR(300) NOT NULL DEFAULT '',
  `password` VARCHAR(100) NOT NULL,
  `ustatus` VARCHAR(10) DEFAULT 'Active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Vehicle details table
-- FIX: brand, model, color are optional but were NOT NULL with no DEFAULT
DROP TABLE IF EXISTS `vehicle_details`;
CREATE TABLE `vehicle_details` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT(10) UNSIGNED NOT NULL,
  `vehicle_number` VARCHAR(20) NOT NULL,
  `vehicle_type` VARCHAR(30) NOT NULL DEFAULT 'Car',
  `vehicle_brand` VARCHAR(50) NOT NULL DEFAULT '',
  `vehicle_model` VARCHAR(50) NOT NULL DEFAULT '',
  `vehicle_color` VARCHAR(30) NOT NULL DEFAULT '',
  `is_default` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Parking cost table
DROP TABLE IF EXISTS `parking_cost`;
CREATE TABLE `parking_cost` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `vehicle_type` VARCHAR(30) NOT NULL DEFAULT 'Car',
  `cost_per_hour` INT(10) UNSIGNED NOT NULL DEFAULT 40,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `parking_cost` (`vehicle_type`, `cost_per_hour`) VALUES
  ('Car', 40),
  ('Bike', 20),
  ('SUV', 60),
  ('Truck', 80);

-- Slot booking table
DROP TABLE IF EXISTS `slot_booking`;
CREATE TABLE `slot_booking` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uname` VARCHAR(100) NOT NULL,
  `uid` VARCHAR(45) NOT NULL,
  `umail` VARCHAR(100) NOT NULL,
  `vehicle_number` VARCHAR(20) NOT NULL DEFAULT '',
  `vehicle_type` VARCHAR(30) NOT NULL DEFAULT 'Car',
  `pdate` VARCHAR(45) NOT NULL,
  `stime` VARCHAR(45) NOT NULL,
  `endtime` VARCHAR(45) NOT NULL,
  `phrs` VARCHAR(10) NOT NULL,
  `slot_name` VARCHAR(45) NOT NULL,
  `pcost` VARCHAR(20) NOT NULL,
  `payment_mode` VARCHAR(30) NOT NULL DEFAULT 'Cash',
  `codeval` VARCHAR(100) DEFAULT NULL,
  `ustatus` VARCHAR(20) NOT NULL DEFAULT 'Pending',
  `booked_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Parking logs table
DROP TABLE IF EXISTS `parking_logs`;
CREATE TABLE `parking_logs` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `booking_id` INT(10) UNSIGNED NOT NULL,
  `uname` VARCHAR(100) NOT NULL,
  `vehicle_number` VARCHAR(20) NOT NULL,
  `slot_name` VARCHAR(45) NOT NULL,
  `entry_time` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `exit_time` TIMESTAMP NULL DEFAULT NULL,
  `status` VARCHAR(20) DEFAULT 'Parked',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
