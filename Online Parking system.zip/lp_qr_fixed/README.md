# QR Code-Based Smart Vehicle Parking System v2.0
## Setup Instructions

### Prerequisites
- Java JDK 11 or above
- Apache Tomcat 9.x or 10.x
- MySQL 5.7 or 8.x
- NetBeans IDE or IntelliJ IDEA (recommended)

---

### Step 1: Database Setup
1. Open MySQL Workbench or phpMyAdmin
2. Run the file: `database/qrparking.sql`
3. This creates the `qrparking` database with all tables

### Step 2: Configure Database Connection
Edit: `src/main/java/com/qrparking/util/DBConnection.java`
```java
private static final String URL = "jdbc:mysql://localhost:3306/qrparking?useSSL=false&serverTimezone=UTC";
private static final String USER = "root";
private static final String PASSWORD = "your_password_here";
```

### Step 3: Build and Deploy
**Option A - Maven:**
```
mvn clean package
```
Deploy the `target/QRParkingSystem.war` to Tomcat's `webapps/` folder.

**Option B - NetBeans:**
1. Open project in NetBeans
2. Right-click > Run (auto-deploys to configured Tomcat)

---

## Default Login Credentials

| Role       | Username      | Password   |
|------------|---------------|------------|
| Admin      | admin         | admin123   |
| User       | Register new account via /Register.jsp |

---

## Features

### User Features
- Register with personal details + optional vehicle
- Add/remove/set default vehicles (Car, Bike, SUV, Truck)
- View parking rates by vehicle type
- Book parking slot (select date, time, duration, vehicle)
- Visual 30-slot parking map with real-time availability
- Download QR-coded parking ticket as image
- View booking history

### Admin Features
- Dashboard with stats (users, vehicles, bookings, revenue)
- View all registered users
- View all registered vehicles with owner info
- View all bookings with filtering
- Update parking cost per vehicle type
- View parking entry logs

### Ticket Checker
- Camera-based QR scanning
- Manual QR code entry
- Ticket verification and logging

---

## Project Structure
```
QRParkingSystem/
├── database/
│   └── qrparking.sql            ← Run this first
├── src/main/
│   ├── java/com/qrparking/
│   │   ├── util/DBConnection.java
│   │   └── servlet/
│   │       ├── AdminLoginServlet.java
│   │       ├── UserLoginServlet.java
│   │       ├── UserRegisterServlet.java
│   │       ├── VehicleServlet.java
│   │       ├── SlotBookingServlet.java
│   │       ├── VerifyTicketServlet.java
│   │       ├── UpdateParkingCostServlet.java
│   │       └── LogoutServlet.java
│   └── webapp/
│       ├── WEB-INF/web.xml
│       ├── css/style.css
│       ├── index.jsp            ← Landing page
│       ├── Administrator.jsp    ← Admin login
│       ├── AdminHome.jsp        ← Admin dashboard
│       ├── Users.jsp            ← User login
│       ├── Register.jsp         ← User registration
│       ├── UserHome.jsp         ← User dashboard
│       ├── MyVehicles.jsp       ← Vehicle management
│       ├── Book_parking.jsp     ← Booking step 1
│       ├── Bookparking.jsp      ← Booking step 2 (slot map)
│       ├── DownloadTicket.jsp   ← QR ticket
│       ├── your_bookings.jsp    ← User booking history
│       ├── Bookings.jsp         ← Admin all bookings
│       ├── ParkingCost.jsp      ← Admin cost management
│       ├── parking_cost1.jsp    ← User cost view
│       ├── UserDetails.jsp      ← Admin user list
│       ├── VehicleDetails.jsp   ← Admin vehicle list
│       ├── ParkingLogs.jsp      ← Admin parking logs
│       ├── CheckParking.jsp     ← QR scanner
│       └── VerifiedTicket.jsp   ← Scan result
└── pom.xml
```

## Bug Fixes Applied
1. Fixed SQL injection - all queries now use PreparedStatement
2. Fixed slot overlap detection - proper time range check (NOT overlap logic)
3. Fixed end time calculation - correct UTC-based time math
4. Fixed Slot 26 bug - was printing "checked" instead of "disabled"
5. Fixed parking cost - cost_update.jsp now uses vehicle_type
6. Fixed session management - all pages check session/role
7. Fixed broken form submissions - all servlet URLs mapped in web.xml
8. Fixed database connection - proper try-with-resources, no connection leaks

## New Features Added
1. Vehicle management module (add, remove, set default)
2. Vehicle-type based parking costs (Car/Bike/SUV/Truck)
3. Admin dashboard with live stats and revenue tracking
4. Improved booking flow with step indicator
5. Visual parking slot grid map with real-time availability
6. Search and filter on all admin tables
7. Modern UI with clean responsive design
8. QR code generation via Google Charts API
9. Downloadable ticket using html2canvas
10. Parking entry log system
